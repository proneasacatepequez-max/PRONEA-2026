/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    remotePatterns: [
      { protocol: 'https', hostname: '**.supabase.co' },
      { protocol: 'https', hostname: 'drive.google.com' },
      { protocol: 'https', hostname: '**.googleusercontent.com' },
    ],
  },
  // Variables de entorno que el CLIENTE puede leer (sin SUPABASE_SERVICE_ROLE_KEY)
  env: {
    NEXT_PUBLIC_APP_NAME: process.env.NEXT_PUBLIC_APP_NAME || 'PRONEA Sacatepéquez',
    NEXT_PUBLIC_APP_VERSION: '3.0.0',
  },
}

module.exports = nextConfig
