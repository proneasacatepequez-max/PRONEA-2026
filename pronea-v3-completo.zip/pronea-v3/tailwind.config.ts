import type { Config } from 'tailwindcss'

const config: Config = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      colors: {
        pronea: {
          DEFAULT: '#0B4F8A',
          secondary: '#0E6FBF',
          light: '#E9F1F9',
          hover: '#1A6DB3',
          dark: '#083A6A',
        },
        estado: {
          activo: '#2EAD65',
          alerta: '#F4C430',
          inactivo: '#D64545',
          info: '#3B82F6',
        },
      },
      fontFamily: {
        sans: ['Nunito', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
      animation: {
        'fade-in': 'fadeIn 0.2s ease both',
        'slide-up': 'slideUp 0.3s ease both',
      },
      keyframes: {
        fadeIn: { from: { opacity: '0', transform: 'translateY(6px)' }, to: { opacity: '1', transform: 'none' } },
        slideUp: { from: { opacity: '0', transform: 'translateY(20px)' }, to: { opacity: '1', transform: 'none' } },
      },
    },
  },
  plugins: [],
}
export default config
