# 🏫 PRONEA Sacatepéquez — Sistema de Gestión Educativa v3.0

**Stack:** Next.js 14 · Supabase (PostgreSQL) · Vercel · TypeScript · Tailwind CSS

---

## ✅ Requisitos previos

- Node.js 18+ instalado ([nodejs.org](https://nodejs.org))
- Git instalado ([git-scm.com](https://git-scm.com))
- Cuenta en GitHub ([github.com](https://github.com))
- Cuenta en Vercel ([vercel.com](https://vercel.com))
- Proyecto Supabase ya creado con las tablas cargadas

---

## 🗄️ PASO 1 — Verificar Supabase

Tu base de datos ya tiene las tablas del esquema v2. Si no ejecutaste la migración v3, hazlo ahora:

1. Entra a **tu proyecto en Supabase**
2. Ve a **SQL Editor → New query**
3. Pega el contenido de `supabase/migrations/pronea_v3_migracion.sql`
4. Haz clic en **Run**
5. Verifica que aparezca `✅` en todos los objetos del resumen final

---

## 💻 PASO 2 — Configurar el proyecto localmente

```bash
# 1. Clona o descarga el proyecto
git clone https://github.com/TU_USUARIO/pronea-sacatepequez.git
cd pronea-sacatepequez

# 2. Instala dependencias
npm install

# 3. Copia el archivo de variables de entorno
cp .env.example .env.local
```

Edita `.env.local` con tus credenciales reales de Supabase:

```env
NEXT_PUBLIC_SUPABASE_URL=https://TU_PROYECTO_ID.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...tu_clave_anonima
SUPABASE_SERVICE_ROLE_KEY=eyJ...tu_clave_de_servicio_PRIVADA
JWT_SECRET=genera_una_cadena_aleatoria_aqui
NEXTAUTH_URL=http://localhost:3000
```

**¿Dónde encuentro las claves de Supabase?**
→ En Supabase: tu proyecto → **Settings → API**

**¿Cómo genero el JWT_SECRET?**
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

```bash
# 4. Prueba el proyecto en desarrollo
npm run dev
# Abre http://localhost:3000
```

---

## 📦 PASO 3 — Subir a GitHub

```bash
# 1. Inicializar repositorio (si no existe)
git init

# 2. Agregar todos los archivos
git add .

# 3. Primer commit
git commit -m "feat: PRONEA Sacatepéquez v3.0 — Sistema completo"

# 4. Crear repositorio en GitHub
# Ve a github.com → New repository → Nombre: pronea-sacatepequez
# Selecciona "Private" (recomendado — contiene código de producción)
# NO marques "Add a README" (ya tenemos uno)

# 5. Conectar y subir
git remote add origin https://github.com/TU_USUARIO/pronea-sacatepequez.git
git branch -M main
git push -u origin main
```

**⚠️ IMPORTANTE:** Verifica que `.env.local` NO esté en el repositorio. El archivo `.gitignore` ya lo excluye, pero confirma con:
```bash
git status  # .env.local NO debe aparecer
```

---

## 🚀 PASO 4 — Desplegar en Vercel

### Opción A — Desde el dashboard de Vercel (recomendado)

1. Ve a [vercel.com](https://vercel.com) → **New Project**
2. Haz clic en **Import Git Repository**
3. Selecciona tu repositorio `pronea-sacatepequez`
4. En **Configure Project**:
   - Framework: **Next.js** (se detecta automáticamente)
   - Root Directory: `.` (dejar en blanco)
5. Ve a **Environment Variables** y agrega **una por una**:

| Variable | Valor |
|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | Tu URL de Supabase |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Tu clave anónima |
| `SUPABASE_SERVICE_ROLE_KEY` | Tu clave de servicio |
| `JWT_SECRET` | Tu cadena secreta |
| `NEXTAUTH_URL` | `https://pronea-sacatepequez.vercel.app` |

6. Haz clic en **Deploy**
7. Espera ~2 minutos. Vercel te dará una URL como `https://pronea-sacatepequez.vercel.app`

### Opción B — Desde la terminal con Vercel CLI

```bash
npm install -g vercel
vercel login
vercel

# Luego agrega las variables:
vercel env add NEXT_PUBLIC_SUPABASE_URL
vercel env add NEXT_PUBLIC_SUPABASE_ANON_KEY
vercel env add SUPABASE_SERVICE_ROLE_KEY
vercel env add JWT_SECRET
vercel env add NEXTAUTH_URL

# Redespliega con las variables
vercel --prod
```

---

## 🔄 PASO 5 — Actualizar el sitio (flujo normal)

Cada vez que hagas cambios al código:

```bash
# 1. Guardar cambios
git add .
git commit -m "feat: descripción del cambio"

# 2. Subir a GitHub
git push

# Vercel detecta el push automáticamente y redespliegua en ~1-2 minutos ✅
```

---

## 👥 Crear el primer usuario administrador

El sistema NO tiene usuarios por defecto. Crea el administrador desde Supabase:

```sql
-- En Supabase SQL Editor:

-- 1. Insertar usuario (contraseña: PRONEA2026admin)
INSERT INTO usuarios (correo, contrasena_hash, rol, activo, primer_ingreso)
VALUES (
  'admin@pronea.gob.gt',
  '$2a$10$YourBcryptHashHere',  -- ver instrucciones abajo
  'administrador',
  TRUE,
  TRUE
);
```

**Para generar el hash de la contraseña** (ejecuta en tu computadora):
```bash
node -e "const b=require('bcryptjs'); b.hash('TuContraseña2026',10).then(h=>console.log(h))"
```

Copia el hash generado y pégalo en el INSERT de arriba.

---

## 📁 Estructura del proyecto

```
pronea-sacatepequez/
├── src/
│   ├── app/
│   │   ├── api/                    # API Routes (servidor)
│   │   │   ├── auth/               # Login, logout
│   │   │   ├── estudiantes/        # CRUD + buscar + inscribir existente
│   │   │   ├── notas/              # Tareas, exámenes, calcular
│   │   │   ├── sireex/             # Grupos SIREEX, exportar CSV
│   │   │   ├── ajustes/            # Ajustes por discapacidad
│   │   │   ├── recursos/           # Recursos pedagógicos
│   │   │   ├── establecimiento/    # Info institucional editable
│   │   │   ├── slider/             # Imágenes del login
│   │   │   ├── configuracion/      # Parámetros del sistema
│   │   │   └── public/             # Endpoints sin auth
│   │   ├── login/                  # Pantalla de login con slider
│   │   └── dashboard/
│   │       ├── admin/              # Dashboard administrador
│   │       │   ├── establecimiento/ # Editar logos, info, slider
│   │       │   ├── recursos/       # Gestionar recursos pedagógicos
│   │       │   ├── sireex/         # Grupos SIREEX (vista admin)
│   │       │   └── libros/         # Gestión libros viejo/nuevo
│   │       ├── tecnico/            # Dashboard técnico
│   │       │   ├── inscribir/      # Buscar + inscribir (evita duplicados)
│   │       │   ├── notas/          # Registro con ajustes discapacidad
│   │       │   └── sireex/         # Crear y gestionar grupos
│   │       ├── director/           # Vista de sede
│   │       ├── coordinador/        # Validación SIREEX
│   │       ├── enlace/             # Institución
│   │       └── estudiante/         # Portal del estudiante
│   ├── components/
│   │   ├── ui/index.tsx            # Todos los componentes reutilizables
│   │   └── layout/Sidebar.tsx      # Navegación lateral por rol
│   ├── lib/
│   │   ├── supabase.ts             # Clientes Supabase
│   │   ├── auth.ts                 # JWT y sesiones
│   │   └── utils.ts                # Helpers + calculadoras de notas
│   └── types/index.ts              # Todos los tipos TypeScript
├── supabase/migrations/
│   ├── pronea_v3_migracion.sql     # Migración v3 completa
│   └── verificacion_completa.sql   # Script para verificar BD
├── .env.example                    # Plantilla de variables de entorno
├── .gitignore                      # Excluye .env.local y node_modules
└── middleware.ts                   # Protección de rutas por rol
```

---

## 🔧 Funcionalidades implementadas

### v3.0 — Nuevas funcionalidades
| Módulo | Descripción |
|---|---|
| **Grupos SIREEX** | Crear grupos por etapa/sede, agregar estudiantes mientras esté abierto, validar que todos tengan código antes de cerrar, exportar CSV oficial |
| **Ajustes por discapacidad** | Registrar adaptaciones curriculares por estudiante: reducción de tareas, omisión de tareas específicas, ajuste de exámenes. El cálculo de promedios respeta los ajustes |
| **Recursos de apoyo** | Videos YouTube, PDFs, libros digitales por etapa/área. Diferenciados de clases Tomi/Classroom. Visibles para estudiantes en su portal |
| **Establecimiento editable** | El administrador edita nombre, logos, director, contacto, horario desde el frontend. Slider de imágenes para el login |
| **Versión de libro** | Cada estudiante tiene libro viejo o nuevo. Las tareas, exámenes y clases Tomi son independientes por versión |

### Funcionalidades base
| Módulo | Descripción |
|---|---|
| **Login** | Autenticación con bloqueo tras intentos fallidos. Panel informativo dinámico desde la BD |
| **Inscripción inteligente** | Busca primero, evita duplicados. Si existe solo crea la inscripción. Si no existe, formulario completo |
| **Notas** | Tareas (0–5) y exámenes (0–100). Cálculo automático de zona y promedio |
| **Portal del estudiante** | Ve sus libros, notas por área, ajustes activos y recursos de apoyo |
| **6 roles** | Administrador, Coordinador DIGEEX, Director, Técnico, Enlace Institucional, Estudiante |

---

## 🆘 Solución de problemas comunes

**Error: `NEXT_PUBLIC_SUPABASE_URL is not defined`**
→ Verifica que las variables estén en Vercel → Settings → Environment Variables

**Error: `JWT_SECRET is not defined`**
→ Asegúrate de que `JWT_SECRET` esté definido en `.env.local` (local) y en Vercel (producción)

**Error 500 en login**
→ Verifica que la tabla `usuarios` tenga registros y que la contraseña esté hasheada con bcrypt

**Las notas no cargan**
→ Verifica que existan registros en `libros` con la `version` correcta ('viejo' o 'nuevo') para la etapa del estudiante

**El slider del login no aparece**
→ Agrega imágenes desde Admin → Establecimiento → Slider

---

*PRONEA Sacatepéquez — Dirección General de Educación Extraescolar (DIGEEX) — MINEDUC Guatemala*
