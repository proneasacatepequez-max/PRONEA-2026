// src/lib/supabase.ts
// ============================================================
// Clientes Supabase — PRONEA v3
//
// REGLA DE ORO:
//   supabase      → usa ANON KEY → seguro en el navegador
//   supabaseAdmin → usa SERVICE ROLE KEY → SOLO en API routes (servidor)
//                   NUNCA importar en componentes 'use client'
// ============================================================
import { createClient } from '@supabase/supabase-js'

const url  = process.env.NEXT_PUBLIC_SUPABASE_URL!
const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
const svc  = process.env.SUPABASE_SERVICE_ROLE_KEY!

// Cliente para el navegador (respeta RLS)
export const supabase = createClient(url, anon)

// Cliente de servicio — solo servidor
export const supabaseAdmin = createClient(url, svc, {
  auth: { autoRefreshToken: false, persistSession: false },
})
