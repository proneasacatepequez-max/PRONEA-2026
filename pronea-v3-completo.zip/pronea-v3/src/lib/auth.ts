// src/lib/auth.ts
import { SignJWT, jwtVerify } from 'jose'
import { cookies } from 'next/headers'
import { NextRequest, NextResponse } from 'next/server'
import type { SessionPayload, RolUsuario } from '@/types'

const secret = new TextEncoder().encode(process.env.JWT_SECRET!)
export const COOKIE = 'pronea_session'
const DIAS = 7

export async function signToken(p: Omit<SessionPayload, 'iat' | 'exp'>) {
  return new SignJWT({ ...p })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime(`${DIAS}d`)
    .sign(secret)
}

export async function verifyToken(token: string): Promise<SessionPayload | null> {
  try {
    const { payload } = await jwtVerify(token, secret)
    return payload as unknown as SessionPayload
  } catch { return null }
}

export async function getSession(req?: NextRequest): Promise<SessionPayload | null> {
  try {
    const token = req
      ? req.cookies.get(COOKIE)?.value
      : cookies().get(COOKIE)?.value
    if (!token) return null
    return verifyToken(token)
  } catch { return null }
}

export function setSession(res: NextResponse, token: string) {
  res.cookies.set(COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 60 * 60 * 24 * DIAS,
    path: '/',
  })
}

export function clearSession(res: NextResponse) { res.cookies.delete(COOKIE) }

export const DASHBOARD: Record<RolUsuario, string> = {
  administrador:        '/dashboard/admin',
  coordinador_digeex:   '/dashboard/coordinador',
  director:             '/dashboard/director',
  tecnico:              '/dashboard/tecnico',
  enlace_institucional: '/dashboard/enlace',
  estudiante:           '/dashboard/estudiante',
}

export function ok(data: unknown, status = 200) {
  return NextResponse.json(data, { status })
}
export function err(msg: string, status = 400) {
  return NextResponse.json({ error: msg }, { status })
}
