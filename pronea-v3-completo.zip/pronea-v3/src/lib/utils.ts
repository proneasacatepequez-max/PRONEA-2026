// src/lib/utils.ts
import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) { return twMerge(clsx(inputs)) }

export function nombreCompleto(o: {
  primer_nombre: string; segundo_nombre?: string | null
  primer_apellido: string; segundo_apellido?: string | null
}) {
  return [o.primer_nombre, o.segundo_nombre, o.primer_apellido, o.segundo_apellido]
    .filter(Boolean).join(' ')
}

export function formatFecha(iso: string) {
  return new Date(iso).toLocaleDateString('es-GT', { year: 'numeric', month: 'long', day: 'numeric' })
}
export function formatFechaCorta(iso: string) {
  return new Date(iso).toLocaleDateString('es-GT', { year: '2-digit', month: '2-digit', day: '2-digit' })
}
export function fechaHoy() {
  return new Date().toLocaleDateString('es-GT', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })
}

// ── Cálculo de promedios ────────────────────────────────────
export interface CfgCalculo {
  pctTareas: number; pctExamenes: number; notaMinima: number
  pesoLibro1: number; pesoLibro2: number
}
export const CFG_DEFAULT: CfgCalculo = {
  pctTareas: 60, pctExamenes: 40, notaMinima: 60, pesoLibro1: 50, pesoLibro2: 50
}

export function calcZona(pts: number, max: number) {
  if (!max) return 0
  return Math.round(pts / max * 100 * 100) / 100
}
export function calcNotaLibro(zona: number, examen: number, cfg = CFG_DEFAULT) {
  return Math.round((zona * cfg.pctTareas / 100 + examen * cfg.pctExamenes / 100) * 100) / 100
}
export function calcEtapa(n1: number | null, n2: number | null, cfg = CFG_DEFAULT) {
  if (n1 === null || n2 === null) return null
  return Math.round((n1 * cfg.pesoLibro1 / 100 + n2 * cfg.pesoLibro2 / 100) * 100) / 100
}
export function calcCualitativa(n: number) {
  if (n >= 90) return 'Excelente'
  if (n >= 80) return 'Muy Bueno'
  if (n >= 70) return 'Bueno'
  if (n >= 60) return 'Suficiente'
  return 'Insuficiente'
}
export function calcPuntosExamen(nota: number) {
  return Math.round(nota * 20 / 100 * 100) / 100
}

// ── Color según nota ────────────────────────────────────────
export function colorNota(n: number | null) {
  if (n === null) return 'text-gray-400'
  if (n >= 70) return 'text-green-600'
  if (n >= 60) return 'text-yellow-600'
  return 'text-red-600'
}
export function bgNota(n: number | null) {
  if (n === null) return 'bg-gray-100 text-gray-500'
  if (n >= 70) return 'bg-green-100 text-green-800'
  if (n >= 60) return 'bg-yellow-100 text-yellow-800'
  return 'bg-red-100 text-red-800'
}

// ── Validaciones ────────────────────────────────────────────
export function validarCUI(cui: string) {
  return /^\d{13}$/.test(cui.replace(/[\s-]/g, ''))
}
export function generarCodigoEstudiante(ciclo: number, seq: number) {
  return `EST-${ciclo}-${String(seq).padStart(4, '0')}`
}
export function generarCodigoSireex(sede: string, ciclo: number, seq: number) {
  return `SIREEX-${sede.substring(0,3).toUpperCase()}-${ciclo}-${String(seq).padStart(3, '0')}`
}
