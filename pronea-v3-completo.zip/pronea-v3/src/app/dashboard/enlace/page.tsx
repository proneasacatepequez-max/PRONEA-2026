// src/app/dashboard/enlace/page.tsx
import { redirect } from 'next/navigation'
import { getSession } from '@/lib/auth'
import { supabaseAdmin } from '@/lib/supabase'
import Link from 'next/link'

export default async function EnlaceDashboard() {
  const s = await getSession(); if (!s||s.rol!=='enlace_institucional') redirect('/login')
  const { data: en } = await supabaseAdmin.from('enlaces_institucionales')
    .select('id,primer_nombre,primer_apellido,cargo,institucion:instituciones(id,nombre,tipo)').eq('usuario_id',s.sub).single()
  if (!en) redirect('/login')
  const instId = (en.institucion as any)?.id
  const [{ count:est },{ count:tec }] = await Promise.all([
    supabaseAdmin.from('inscripciones').select('*',{count:'exact',head:true}).eq('institucion_id',instId).eq('ciclo_escolar',2026),
    supabaseAdmin.from('tecnico_instituciones').select('*',{count:'exact',head:true}).eq('institucion_id',instId).eq('activo',true),
  ])
  return (
    <div className="animate-page">
      <header className="topbar"><div><div className="page-title">{(en.institucion as any)?.nombre}</div><div className="text-xs text-gray-400">{en.primer_nombre} {en.primer_apellido} — {en.cargo}</div></div></header>
      <div className="page-content">
        <div className="grid-3">
          <div className="stat-card blue"><div className="text-3xl mb-1">🎓</div><div className="text-3xl font-extrabold text-gray-800">{est??0}</div><div className="text-sm text-gray-500 font-semibold">Estudiantes inscritos</div></div>
          <div className="stat-card green"><div className="text-3xl mb-1">👨‍🏫</div><div className="text-3xl font-extrabold text-gray-800">{tec??0}</div><div className="text-sm text-gray-500 font-semibold">Técnicos activos</div></div>
          <div className="stat-card yellow"><div className="text-3xl mb-1">🏛️</div><div className="text-base font-extrabold text-gray-800">{(en.institucion as any)?.tipo??'—'}</div><div className="text-sm text-gray-500 font-semibold">Tipo de institución</div></div>
        </div>
        <div className="card">
          <div className="card-title">⚡ Acciones</div>
          <div className="grid grid-cols-2 gap-3">
            <Link href="/dashboard/enlace/docentes" className="btn btn-primary justify-center">👨‍🏫 Inscribir técnico</Link>
            <Link href="/dashboard/enlace/estudiantes" className="btn btn-ghost justify-center">🎓 Ver estudiantes</Link>
            <Link href="/dashboard/enlace/reportes" className="btn btn-ghost justify-center col-span-2">📈 Reportes de mi institución</Link>
          </div>
        </div>
      </div>
    </div>
  )
}
