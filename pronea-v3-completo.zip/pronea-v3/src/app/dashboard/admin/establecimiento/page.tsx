'use client'
// src/app/dashboard/admin/establecimiento/page.tsx
// El administrador puede editar: nombre, logos, director, contacto, slider
import { useState, useEffect } from 'react'
import { FormGroup, Input, Textarea, LoadingBtn, Alert } from '@/components/ui'
import type { InfoEstablecimiento, SliderImagen } from '@/types'

export default function EstablecimientoPage() {
  const [info, setInfo] = useState<Partial<InfoEstablecimiento>>({})
  const [slider, setSlider] = useState<SliderImagen[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [msg, setMsg] = useState('')
  const [tab, setTab] = useState<'info'|'logos'|'slider'>('info')
  const [nuevaImg, setNuevaImg] = useState({ url_imagen:'', titulo:'', orden:0 })

  useEffect(()=>{
    Promise.all([
      fetch('/api/establecimiento').then(r=>r.json()),
      fetch('/api/slider').then(r=>r.json()).catch(()=>[]),
    ]).then(([est, sl])=>{ setInfo(est??{}); setSlider(sl??[]) }).finally(()=>setLoading(false))
  },[])

  const save = async () => {
    setSaving(true); setMsg('')
    const res = await fetch('/api/establecimiento',{ method:'PUT', headers:{'Content-Type':'application/json'}, body:JSON.stringify(info) })
    const d = await res.json()
    setMsg(res.ok?'✅ Guardado correctamente':'❌ '+d.error)
    setSaving(false)
  }

  const addSlider = async () => {
    if (!nuevaImg.url_imagen) return
    const res = await fetch('/api/slider',{ method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(nuevaImg) })
    if (res.ok) {
      const d = await res.json()
      setSlider(s=>[...s,{...nuevaImg,id:d.id,activo:true}])
      setNuevaImg({url_imagen:'',titulo:'',orden:0})
    }
  }

  const setF = (k: keyof InfoEstablecimiento, v: string) => setInfo(i=>({...i,[k]:v}))

  if (loading) return <div className="animate-page"><div className="topbar"><div className="page-title">Establecimiento</div></div><div className="page-content text-gray-400 py-20 text-center">Cargando...</div></div>

  return (
    <div className="animate-page">
      <header className="topbar">
        <div className="page-title">🏛️ Configuración del Establecimiento</div>
        <LoadingBtn loading={saving} className="btn btn-primary" onClick={save}>💾 Guardar cambios</LoadingBtn>
      </header>
      <div className="page-content max-w-4xl">
        {msg && <Alert type={msg.startsWith('✅')?'success':'error'}>{msg}</Alert>}

        {/* Tabs */}
        <div className="flex gap-1 bg-gray-100 p-1 rounded-xl mb-5">
          {(['info','logos','slider'] as const).map(t=>(
            <button key={t} onClick={()=>setTab(t)}
              className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${tab===t?'bg-white text-pronea shadow-sm':'text-gray-500'}`}>
              {t==='info'?'📋 Información':t==='logos'?'🖼️ Logos':'🎬 Slider Login'}
            </button>
          ))}
        </div>

        {/* INFO */}
        {tab==='info' && (
          <div className="card">
            <div className="card-title">Información institucional</div>
            <div className="fgrid2">
              <FormGroup label="Nombre completo" required><Input value={info.nombre_completo??''} onChange={e=>setF('nombre_completo',e.target.value)}/></FormGroup>
              <FormGroup label="Nombre corto"><Input value={info.nombre_corto??''} onChange={e=>setF('nombre_corto',e.target.value)}/></FormGroup>
              <FormGroup label="Departamento"><Input value={info.departamento??''} onChange={e=>setF('departamento',e.target.value)}/></FormGroup>
              <FormGroup label="Municipio"><Input value={info.municipio??''} onChange={e=>setF('municipio',e.target.value)}/></FormGroup>
              <FormGroup label="Nombre del Director"><Input value={info.director_nombre??''} onChange={e=>setF('director_nombre',e.target.value)} placeholder="Lic. Juan Pérez"/></FormGroup>
              <FormGroup label="Título del Director"><Input value={info.director_titulo??''} onChange={e=>setF('director_titulo',e.target.value)} placeholder="Director Departamental"/></FormGroup>
              <FormGroup label="Teléfono"><Input value={info.telefono??''} onChange={e=>setF('telefono',e.target.value)}/></FormGroup>
              <FormGroup label="WhatsApp"><Input value={info.whatsapp??''} onChange={e=>setF('whatsapp',e.target.value)}/></FormGroup>
              <FormGroup label="Correo institucional"><Input type="email" value={info.correo??''} onChange={e=>setF('correo',e.target.value)}/></FormGroup>
              <FormGroup label="Facebook"><Input value={info.facebook??''} onChange={e=>setF('facebook',e.target.value)}/></FormGroup>
              <FormGroup label="Sitio Web"><Input value={info.sitio_web??''} onChange={e=>setF('sitio_web',e.target.value)}/></FormGroup>
            </div>
            <FormGroup label="Dirección"><Textarea value={info.direccion??''} onChange={e=>setF('direccion',e.target.value)}/></FormGroup>
            <FormGroup label="Horario de atención" hint="Ej: Lunes a Viernes 8:00-16:00 / Sábados 8:00-12:00"><Textarea rows={2} value={info.horario_atencion??''} onChange={e=>setF('horario_atencion',e.target.value)}/></FormGroup>
          </div>
        )}

        {/* LOGOS */}
        {tab==='logos' && (
          <div className="card">
            <div className="card-title">Logos institucionales</div>
            <div className="alert alert-i mb-4">💡 Ingresa la URL pública de la imagen. Puedes subir imágenes a Supabase Storage o usar Google Drive (enlace de vista directa).</div>
            {[
              { field:'logo_url' as const, label:'Logo PRONEA principal', desc:'Aparece en login y sidebar' },
              { field:'logo_mineduc_url' as const, label:'Logo MINEDUC', desc:'Aparece en encabezados oficiales y escalas' },
              { field:'logo_digeex_url' as const, label:'Logo DIGEEX', desc:'Aparece en reportes y escalas' },
              { field:'logo_establecimiento_url' as const, label:'Logo del Establecimiento', desc:'Logo local de la sede principal' },
            ].map(({ field, label, desc })=>(
              <div key={field} className="border border-gray-100 rounded-xl p-4 mb-3">
                <div className="flex items-start gap-4">
                  <div className="w-20 h-20 rounded-lg border border-gray-200 flex items-center justify-center bg-gray-50 flex-shrink-0 overflow-hidden">
                    {info[field]
                      ? <img src={info[field]!} alt={label} className="w-full h-full object-contain p-1"/>
                      : <span className="text-gray-300 text-3xl">🖼️</span>
                    }
                  </div>
                  <div className="flex-1">
                    <div className="text-sm font-bold text-gray-700 mb-0.5">{label}</div>
                    <div className="text-xs text-gray-400 mb-2">{desc}</div>
                    <Input value={info[field]??''} onChange={e=>setF(field,e.target.value)} placeholder="https://..."/>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* SLIDER */}
        {tab==='slider' && (
          <div className="card">
            <div className="card-title">Imágenes del slider (pantalla de login)</div>
            <div className="alert alert-i mb-4">💡 Las imágenes aparecen como fondo del panel informativo en el login. Usa imágenes públicas de 1200×800px o superior.</div>

            {/* Imágenes existentes */}
            <div className="space-y-2 mb-5">
              {slider.map(img=>(
                <div key={img.id} className="flex items-center gap-3 p-3 border border-gray-100 rounded-lg">
                  <img src={img.url_imagen} alt={img.titulo??''} className="w-16 h-10 object-cover rounded"/>
                  <div className="flex-1">
                    <div className="text-sm font-semibold text-gray-700">{img.titulo??'Sin título'}</div>
                    <div className="text-xs text-gray-400 truncate">{img.url_imagen}</div>
                  </div>
                  <span className={`badge ${img.activo?'badge-green':'badge-gray'}`}>{img.activo?'Activo':'Inactivo'}</span>
                </div>
              ))}
            </div>

            {/* Agregar nueva */}
            <div className="border border-dashed border-gray-200 rounded-xl p-4">
              <div className="text-sm font-bold text-gray-600 mb-3">➕ Agregar imagen</div>
              <FormGroup label="URL de la imagen"><Input value={nuevaImg.url_imagen} onChange={e=>setNuevaImg(n=>({...n,url_imagen:e.target.value}))} placeholder="https://..."/></FormGroup>
              <div className="fgrid2">
                <FormGroup label="Título (opcional)"><Input value={nuevaImg.titulo} onChange={e=>setNuevaImg(n=>({...n,titulo:e.target.value}))}/></FormGroup>
                <FormGroup label="Orden"><Input type="number" value={nuevaImg.orden} onChange={e=>setNuevaImg(n=>({...n,orden:parseInt(e.target.value)||0}))}/></FormGroup>
              </div>
              <button className="btn btn-primary" onClick={addSlider}>➕ Agregar al slider</button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
