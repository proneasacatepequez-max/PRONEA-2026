// src/app/dashboard/admin/page.tsx
import { redirect } from 'next/navigation'
import { getSession } from '@/lib/auth'
import { supabaseAdmin } from '@/lib/supabase'
import Link from 'next/link'

export default async function AdminDashboard() {
  const s = await getSession(); if (!s||s.rol!=='administrador') redirect('/login')

  const [
    { count: totalEst },
    { count: totalTec },
    { count: totalSedes },
    { count: librosEnProg },
  ] = await Promise.all([
    supabaseAdmin.from('inscripciones').select('*',{count:'exact',head:true}).eq('ciclo_escolar',2026).eq('estado','en_curso'),
    supabaseAdmin.from('tecnicos').select('*',{count:'exact',head:true}).eq('activo',true),
    supabaseAdmin.from('sedes').select('*',{count:'exact',head:true}).eq('activo',true),
    supabaseAdmin.from('resumen_libro').select('*',{count:'exact',head:true}).eq('estado','en_progreso'),
  ])

  const { data: porVersion } = await supabaseAdmin.from('inscripciones')
    .select('version_libro').eq('ciclo_escolar',2026).eq('estado','en_curso')
  const vCount = { nuevo:0, viejo:0 }
  porVersion?.forEach((i:any)=>{ vCount[i.version_libro as 'nuevo'|'viejo']++ })

  const { data: grupos } = await supabaseAdmin.from('grupos_sireex')
    .select('id,codigo,estado').eq('ciclo_escolar',2026).order('creado_en',{ascending:false}).limit(5)

  const { data: auditoria } = await supabaseAdmin.from('auditoria')
    .select('id,accion,tabla_afectada,creado_en').order('creado_en',{ascending:false}).limit(8)

  const hoy = new Date().toLocaleDateString('es-GT',{weekday:'long',year:'numeric',month:'long',day:'numeric'})

  return (
    <div className="animate-page">
      <header className="topbar">
        <div className="page-title">Dashboard Administrador</div>
        <div className="text-sm text-gray-400">{hoy}</div>
      </header>
      <div className="page-content">
        {/* Stats */}
        <div className="grid-4">
          <div className="stat-card blue"><div className="text-3xl mb-1">🎓</div><div className="text-3xl font-extrabold text-gray-800">{totalEst??0}</div><div className="text-sm text-gray-500 font-semibold">Estudiantes inscritos</div></div>
          <div className="stat-card green"><div className="text-3xl mb-1">👨‍🏫</div><div className="text-3xl font-extrabold text-gray-800">{totalTec??0}</div><div className="text-sm text-gray-500 font-semibold">Técnicos activos</div></div>
          <div className="stat-card yellow"><div className="text-3xl mb-1">🏫</div><div className="text-3xl font-extrabold text-gray-800">{totalSedes??0}</div><div className="text-sm text-gray-500 font-semibold">Sedes activas</div></div>
          <div className="stat-card red"><div className="text-3xl mb-1">⏳</div><div className="text-3xl font-extrabold text-gray-800">{librosEnProg??0}</div><div className="text-sm text-gray-500 font-semibold">Libros en progreso</div></div>
        </div>

        <div className="grid-2">
          {/* Versión de libros */}
          <div className="card">
            <div className="card-title">📚 Distribución por versión de libro <span className="text-xs text-gray-400 font-normal">Ciclo 2026</span></div>
            <div className="flex gap-4">
              <div className="flex-1 bg-blue-50 rounded-xl p-4 text-center">
                <div className="text-4xl font-extrabold text-blue-700">{vCount.nuevo}</div>
                <div className="text-sm font-bold text-blue-600 mt-1">📗 Libro Nuevo</div>
                <div className="text-xs text-gray-400">{totalEst?Math.round(vCount.nuevo/(totalEst||1)*100):0}%</div>
              </div>
              <div className="flex-1 bg-orange-50 rounded-xl p-4 text-center">
                <div className="text-4xl font-extrabold text-orange-700">{vCount.viejo}</div>
                <div className="text-sm font-bold text-orange-600 mt-1">📙 Libro Viejo</div>
                <div className="text-xs text-orange-400">En transición</div>
              </div>
            </div>
          </div>

          {/* Accesos rápidos */}
          <div className="card">
            <div className="card-title">⚡ Accesos rápidos</div>
            <div className="grid grid-cols-2 gap-2">
              {[
                {href:'/dashboard/admin/usuarios',       icon:'👥', label:'Usuarios'},
                {href:'/dashboard/admin/libros',         icon:'📚', label:'Libros'},
                {href:'/dashboard/admin/sireex',         icon:'📤', label:'Grupos SIREEX'},
                {href:'/dashboard/admin/ajustes',        icon:'♿', label:'Ajustes discap.'},
                {href:'/dashboard/admin/recursos',       icon:'🎬', label:'Recursos'},
                {href:'/dashboard/admin/establecimiento',icon:'🏛️', label:'Establecimiento'},
                {href:'/dashboard/admin/configuracion',  icon:'⚙️', label:'Configuración'},
                {href:'/dashboard/admin/auditoria',      icon:'📋', label:'Auditoría'},
              ].map(({ href, icon, label })=>(
                <Link key={href} href={href}
                  className="flex items-center gap-2 p-2.5 rounded-lg border border-gray-100 hover:border-pronea-secondary hover:bg-pronea-light transition-all text-sm font-semibold text-gray-700">
                  <span>{icon}</span><span>{label}</span>
                </Link>
              ))}
            </div>
          </div>
        </div>

        <div className="grid-2">
          {/* Grupos SIREEX recientes */}
          <div className="card">
            <div className="card-title">
              📤 Grupos SIREEX recientes
              <Link href="/dashboard/admin/sireex" className="text-xs text-pronea-secondary hover:underline">Ver todos</Link>
            </div>
            {(!grupos||grupos.length===0)
              ? <div className="text-sm text-gray-400 py-4 text-center">Sin grupos creados</div>
              : <div className="space-y-2">
                  {grupos.map((g:any)=>(
                    <div key={g.id} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
                      <span className="text-sm font-semibold text-gray-700">{g.codigo}</span>
                      <span className={`badge ${g.estado==='abierto'?'badge-green':g.estado==='cerrado'?'badge-yellow':'badge-blue'}`}>{g.estado}</span>
                    </div>
                  ))}
                </div>
            }
          </div>

          {/* Actividad reciente */}
          <div className="card">
            <div className="card-title">
              🔔 Actividad reciente
              <Link href="/dashboard/admin/auditoria" className="text-xs text-pronea-secondary hover:underline">Ver todo</Link>
            </div>
            <div className="space-y-2">
              {(auditoria??[]).map((a:any)=>(
                <div key={a.id} className="flex items-center gap-2 py-1.5 text-sm border-b border-gray-50 last:border-0">
                  <div className="w-2 h-2 rounded-full bg-pronea-secondary flex-shrink-0"/>
                  <div className="flex-1 font-semibold text-gray-700 truncate">{a.accion} — {a.tabla_afectada}</div>
                  <div className="text-xs text-gray-400 flex-shrink-0">{new Date(a.creado_en).toLocaleTimeString('es-GT',{hour:'2-digit',minute:'2-digit'})}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
