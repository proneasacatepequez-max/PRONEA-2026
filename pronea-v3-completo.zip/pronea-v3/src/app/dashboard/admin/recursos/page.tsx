'use client'
// src/app/dashboard/admin/recursos/page.tsx
import { useState, useEffect } from 'react'
import { FormGroup, Input, Select, Textarea, Modal, LoadingBtn, Spinner, Empty, Alert, Badge } from '@/components/ui'
import { ETAPAS_LISTA } from '@/types'

export default function RecursosAdminPage() {
  const [recursos,setRecursos] = useState<any[]>([])
  const [categorias,setCategorias] = useState<any[]>([])
  const [loading,setLoading] = useState(true)
  const [modal,setModal] = useState(false)
  const [saving,setSaving] = useState(false)
  const [err,setErr] = useState('')
  const [form,setForm] = useState({ titulo:'',descripcion:'',url:'',tipo_contenido:'video_youtube',etapa_id:'',area_id:'',categoria_id:'',duracion_minutos:'',es_publico:true,destacado:false,orden:'0' })

  const cargar = async()=>{
    setLoading(true)
    const [r,c]=await Promise.all([fetch('/api/recursos').then(r=>r.json()),fetch('/api/categorias-recurso').then(r=>r.json()).catch(()=>[])])
    setRecursos(Array.isArray(r)?r:[]); setCategorias(Array.isArray(c)?c:[])
    setLoading(false)
  }
  useEffect(()=>{cargar()},[])

  const guardar=async()=>{
    if(!form.titulo||!form.url){setErr('Título y URL requeridos');return}
    setSaving(true);setErr('')
    const res=await fetch('/api/recursos',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...form,etapa_id:form.etapa_id?parseInt(form.etapa_id):null,categoria_id:form.categoria_id?parseInt(form.categoria_id):null,duracion_minutos:form.duracion_minutos?parseInt(form.duracion_minutos):null,orden:parseInt(form.orden)})})
    const d=await res.json()
    if(!res.ok){setErr(d.error??'Error');setSaving(false);return}
    setModal(false);cargar();setSaving(false)
  }

  const TIPOS=[{v:'video_youtube',l:'Video YouTube'},{v:'video_drive',l:'Video Drive'},{v:'pdf_drive',l:'PDF Drive'},{v:'documento_word',l:'Documento Word'},{v:'libro_digital',l:'Libro Digital'},{v:'formulario',l:'Formulario'},{v:'imagen',l:'Imagen/Infografía'},{v:'audio',l:'Audio'},{v:'enlace_web',l:'Página Web'},{v:'otro',l:'Otro'}]

  return (
    <div className="animate-page">
      <header className="topbar">
        <div className="page-title">🎬 Recursos de Apoyo Pedagógico</div>
        <button className="btn btn-primary" onClick={()=>setModal(true)}>＋ Nuevo recurso</button>
      </header>
      <div className="page-content">
        <div className="alert alert-i mb-4">
          💡 <b>Recursos de apoyo</b> son diferentes de los <b>enlaces de evaluación Tomi/Classroom</b>. Aquí registras videos, PDFs, libros digitales y formularios para apoyar el aprendizaje.
        </div>
        {loading?<Spinner/>:recursos.length===0?<Empty icon="🎬" msg="Sin recursos registrados aún"/>:(
          <div className="grid gap-3 grid-cols-1 md:grid-cols-2">
            {recursos.map((r:any)=>(
              <div key={r.id} className="card">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-lg bg-blue-50 flex items-center justify-center text-xl flex-shrink-0">
                    {r.tipo_contenido==='video_youtube'||r.tipo_contenido==='video_drive'?'▶️':r.tipo_contenido==='pdf_drive'?'📕':r.tipo_contenido==='libro_digital'?'📚':'🔗'}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-bold text-sm text-gray-800">{r.titulo}</div>
                    <div className="text-xs text-gray-400 mt-0.5 truncate">{r.url}</div>
                    <div className="flex flex-wrap gap-1 mt-1.5">
                      {r.categoria&&<span className="badge badge-blue text-[10px]">{r.categoria.nombre}</span>}
                      {r.etapa&&<span className="badge badge-gray text-[10px]">{r.etapa.nombre}</span>}
                      {r.area&&<span className="badge badge-gray text-[10px]">{r.area.nombre}</span>}
                      {r.destacado&&<span className="badge badge-yellow text-[10px]">⭐ Destacado</span>}
                      <span className={`badge text-[10px] ${r.es_publico?'badge-green':'badge-gray'}`}>{r.es_publico?'Público':'Solo técnicos'}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <Modal open={modal} onClose={()=>setModal(false)} title="➕ Nuevo Recurso de Apoyo" size="lg"
        footer={<><button className="btn btn-ghost" onClick={()=>setModal(false)}>Cancelar</button><LoadingBtn loading={saving} className="btn btn-primary" onClick={guardar}>💾 Guardar</LoadingBtn></>}>
        {err&&<Alert type="error">{err}</Alert>}
        <div className="fgrid2">
          <FormGroup label="Título" required className="col-span-2"><Input value={form.titulo} onChange={e=>setForm(f=>({...f,titulo:e.target.value}))}/></FormGroup>
          <FormGroup label="URL" required className="col-span-2"><Input type="url" value={form.url} onChange={e=>setForm(f=>({...f,url:e.target.value}))} placeholder="https://..."/></FormGroup>
          <FormGroup label="Tipo de contenido"><Select value={form.tipo_contenido} onChange={e=>setForm(f=>({...f,tipo_contenido:e.target.value}))}>{TIPOS.map(t=><option key={t.v} value={t.v}>{t.l}</option>)}</Select></FormGroup>
          <FormGroup label="Categoría"><Select value={form.categoria_id} onChange={e=>setForm(f=>({...f,categoria_id:e.target.value}))}><option value="">— Seleccionar —</option>{categorias.map((c:any)=><option key={c.id} value={c.id}>{c.nombre}</option>)}</Select></FormGroup>
          <FormGroup label="Etapa (opcional)"><Select value={form.etapa_id} onChange={e=>setForm(f=>({...f,etapa_id:e.target.value}))}><option value="">Todas las etapas</option>{ETAPAS_LISTA.map(e=><option key={e.id} value={e.id}>{e.nombre}</option>)}</Select></FormGroup>
          <FormGroup label="Duración (minutos)"><Input type="number" value={form.duracion_minutos} onChange={e=>setForm(f=>({...f,duracion_minutos:e.target.value}))}/></FormGroup>
          <FormGroup label="Orden"><Input type="number" value={form.orden} onChange={e=>setForm(f=>({...f,orden:e.target.value}))}/></FormGroup>
        </div>
        <FormGroup label="Descripción"><Textarea value={form.descripcion} onChange={e=>setForm(f=>({...f,descripcion:e.target.value}))}/></FormGroup>
        <div className="flex gap-4">
          <label className="flex items-center gap-2 text-sm font-semibold text-gray-600 cursor-pointer"><input type="checkbox" checked={form.es_publico} onChange={e=>setForm(f=>({...f,es_publico:e.target.checked}))} className="w-4 h-4"/>Visible para estudiantes</label>
          <label className="flex items-center gap-2 text-sm font-semibold text-gray-600 cursor-pointer"><input type="checkbox" checked={form.destacado} onChange={e=>setForm(f=>({...f,destacado:e.target.checked}))} className="w-4 h-4"/>⭐ Destacado</label>
        </div>
      </Modal>
    </div>
  )
}
