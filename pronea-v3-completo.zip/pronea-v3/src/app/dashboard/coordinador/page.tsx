// src/app/dashboard/coordinador/page.tsx
import { redirect } from 'next/navigation'
import { getSession } from '@/lib/auth'
import { supabaseAdmin } from '@/lib/supabase'
import Link from 'next/link'

export default async function CoordinadorDashboard() {
  const s = await getSession(); if (!s||s.rol!=='coordinador_digeex') redirect('/login')
  const [{ count:listos },{ count:validados },{ count:exportados },{ count:grupos }] = await Promise.all([
    supabaseAdmin.from('resumen_etapa').select('*',{count:'exact',head:true}).eq('validado_digeex',false).not('nota_final_etapa','is',null),
    supabaseAdmin.from('resumen_etapa').select('*',{count:'exact',head:true}).eq('validado_digeex',true).eq('exportado_sireex',false),
    supabaseAdmin.from('grupos_sireex').select('*',{count:'exact',head:true}).eq('estado','exportado').eq('ciclo_escolar',2026),
    supabaseAdmin.from('grupos_sireex').select('*',{count:'exact',head:true}).eq('estado','abierto').eq('ciclo_escolar',2026),
  ])
  return (
    <div className="animate-page">
      <header className="topbar"><div className="page-title">Coordinador DIGEEX — Validación SIREEX</div></header>
      <div className="page-content">
        <div className="grid-4">
          <div className="stat-card green"><div className="text-3xl mb-1">✅</div><div className="text-3xl font-extrabold text-gray-800">{listos??0}</div><div className="text-sm text-gray-500 font-semibold">Listos para validar</div></div>
          <div className="stat-card blue"><div className="text-3xl mb-1">🔍</div><div className="text-3xl font-extrabold text-gray-800">{validados??0}</div><div className="text-sm text-gray-500 font-semibold">Validados sin exportar</div></div>
          <div className="stat-card yellow"><div className="text-3xl mb-1">📤</div><div className="text-3xl font-extrabold text-gray-800">{exportados??0}</div><div className="text-sm text-gray-500 font-semibold">Grupos exportados</div></div>
          <div className="stat-card red"><div className="text-3xl mb-1">📂</div><div className="text-3xl font-extrabold text-gray-800">{grupos??0}</div><div className="text-sm text-gray-500 font-semibold">Grupos aún abiertos</div></div>
        </div>
        <div className="card">
          <div className="card-title">⚡ Acciones</div>
          <div className="grid grid-cols-2 gap-3">
            <Link href="/dashboard/coordinador/grupos" className="btn btn-primary justify-center">📤 Ver grupos SIREEX</Link>
            <Link href="/dashboard/coordinador/exportar" className="btn btn-success justify-center">📥 Exportar CSV</Link>
            <Link href="/dashboard/coordinador/alertas" className="btn btn-warning justify-center">⚠️ Alertas</Link>
            <Link href="/dashboard/coordinador/reportes" className="btn btn-ghost justify-center">📈 Reporte consolidado</Link>
          </div>
        </div>
      </div>
    </div>
  )
}
