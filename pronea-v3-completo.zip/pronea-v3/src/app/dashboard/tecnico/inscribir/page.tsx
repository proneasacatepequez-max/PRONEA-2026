'use client'
// src/app/dashboard/tecnico/inscribir/page.tsx
// Flujo: Buscar → si existe solo inscripción / si no existe formulario completo
import { useState } from 'react'
import { FormGroup, Input, Select, Alert, SelectorVersionLibro, Steps, LoadingBtn } from '@/components/ui'
import { ETAPAS_LISTA, MUNICIPIOS_SAC } from '@/types'

const DISC = [{id:1,n:'Ninguna'},{id:2,n:'Intelectual Leve'},{id:3,n:'Intelectual Moderada'},{id:4,n:'Intelectual Grave'},{id:5,n:'Intelectual Profunda'},{id:6,n:'TEA'},{id:7,n:'Visual'},{id:8,n:'Baja Visión'},{id:9,n:'Auditiva'},{id:10,n:'Pérdida Auditiva Leve'},{id:11,n:'Física o Motora'},{id:12,n:'Mental'},{id:13,n:'Múltiple'},{id:14,n:'Gente Pequeña'},{id:15,n:'Problemas de Aprendizaje'},{id:16,n:'Pendiente'}]
const SECC = ['A','A1','A2','A3','A4','A5','A6','AA','AB','B','C','C1','D','D1']

type Modo = 'buscar'|'encontrado'|'nuevo'
const INSC_INIT = { etapa_id:'',sede_id:'',modalidad_id:'1',seccion_id:'',ciclo_escolar:'2026',repite_etapa:false,estado_classroom:'',codigo_sireex:'',observaciones:'',version_libro:'nuevo' as 'nuevo'|'viejo' }

export default function InscribirPage() {
  const [modo,setModo] = useState<Modo>('buscar')
  const [paso,setPaso] = useState(1)
  const [busq,setBusq] = useState({tipo:'cui',val:''})
  const [buscando,setBuscando] = useState(false)
  const [resultados,setResultados] = useState<any[]>([])
  const [estSel,setEstSel] = useState<any>(null)
  const [errBusq,setErrBusq] = useState('')
  const [per,setPer] = useState({ primer_nombre:'',segundo_nombre:'',primer_apellido:'',segundo_apellido:'',apellido_casada:'',cui:'',cui_pendiente:false,fecha_nacimiento:'',genero:'',telefono:'',telefono_alternativo:'',correo:'',correo_classroom:'',direccion:'',municipio_id:'',discapacidad_id:'1',conflicto_ley:false,becado_por:'' })
  const [insc,setInsc] = useState(INSC_INIT)
  const [docs,setDocs] = useState([{tipo_documento_id:1,label:'DPI (ambos lados) *',url:'',req:true},{tipo_documento_id:2,label:'Certificado de nacimiento *',url:'',req:true},{tipo_documento_id:4,label:'Fotografía reciente *',url:'',req:true},{tipo_documento_id:3,label:'Constancia de estudios',url:'',req:false}])
  const [saving,setSaving] = useState(false)
  const [err,setErr] = useState('')
  const [ok,setOk] = useState<any>(null)

  const reset = () => { setModo('buscar');setPaso(1);setResultados([]);setEstSel(null);setErr('');setErrBusq('');setBusq({tipo:'cui',val:''}); setInsc(INSC_INIT) }

  const buscar = async () => {
    if (!busq.val.trim()) { setErrBusq('Ingresa un valor'); return }
    setBuscando(true); setErrBusq(''); setResultados([])
    const p = new URLSearchParams(); p.set(busq.tipo==='cui'?'cui':busq.tipo==='codigo'?'codigo':'nombre',busq.val)
    const res = await fetch(`/api/estudiantes/buscar?${p}`).then(r=>r.json())
    if (res.encontrado) setResultados(res.estudiantes)
    else { setModo('nuevo'); if(busq.tipo==='cui') setPer(pp=>({...pp,cui:busq.val})) }
    setBuscando(false)
  }

  const guardarExistente = async () => {
    if (!estSel||!insc.etapa_id||!insc.sede_id) { setErr('Etapa y sede requeridos'); return }
    setSaving(true); setErr('')
    const res = await fetch(`/api/estudiantes/${estSel.id}/inscribir`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...insc,etapa_id:parseInt(insc.etapa_id),ciclo_escolar:parseInt(insc.ciclo_escolar),modalidad_id:insc.modalidad_id?parseInt(insc.modalidad_id):null,seccion_id:insc.seccion_id?parseInt(insc.seccion_id):null})})
    const d = await res.json()
    if (res.status===409) { setErr(d.message); setSaving(false); return }
    if (!res.ok) { setErr(d.error??'Error'); setSaving(false); return }
    setOk({codigo:d.codigo_estudiante,nombre:d.estudiante,tipo:'existente',id:d.inscripcion_id})
    setSaving(false)
  }

  const guardarNuevo = async () => {
    setSaving(true); setErr('')
    const res = await fetch('/api/estudiantes',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...per,municipio_id:per.municipio_id?parseInt(per.municipio_id):null,discapacidad_id:parseInt(per.discapacidad_id),...insc,etapa_id:parseInt(insc.etapa_id),ciclo_escolar:parseInt(insc.ciclo_escolar),modalidad_id:insc.modalidad_id?parseInt(insc.modalidad_id):null,seccion_id:insc.seccion_id?parseInt(insc.seccion_id):null,documentos:docs.filter(d=>d.url).map(d=>({tipo_documento_id:d.tipo_documento_id,url_google_drive:d.url}))})})
    const d = await res.json()
    if (!res.ok) { setErr(d.error??'Error'); setSaving(false); return }
    setOk({codigo:d.codigo_estudiante,nombre:`${per.primer_nombre} ${per.primer_apellido}`,tipo:'nuevo',id:d.inscripcion_id})
    setSaving(false)
  }

  if (ok) return (
    <div className="animate-page">
      <header className="topbar"><div className="page-title">➕ Inscribir Estudiante</div></header>
      <div className="page-content flex justify-center">
        <div className="card max-w-md text-center">
          <div className="text-6xl mb-3">🎉</div>
          <h2 className="text-xl font-extrabold text-gray-800 mb-1">{ok.tipo==='nuevo'?'¡Estudiante inscrito!':'¡Inscripción creada!'}</h2>
          <p className="text-sm text-gray-400 mb-4">{ok.tipo==='nuevo'?'Nuevo registro creado en la BD.':'Inscripción agregada al estudiante existente.'}</p>
          <div className="bg-green-50 rounded-xl p-4 text-left mb-4">
            <div className="text-sm font-bold text-green-800">{ok.nombre}</div>
            <div className="text-2xl font-extrabold text-green-700 mt-1">{ok.codigo}</div>
            <div className="text-xs text-green-400 mt-1 font-mono">{ok.id}</div>
          </div>
          <div className="flex gap-2">
            <button className="btn btn-primary flex-1" onClick={()=>{setOk(null);reset()}}>➕ Nueva inscripción</button>
            <a href="/dashboard/tecnico/estudiantes" className="btn btn-ghost flex-1">Ver estudiantes</a>
          </div>
        </div>
      </div>
    </div>
  )

  return (
    <div className="animate-page">
      <header className="topbar">
        <div className="page-title">➕ Inscribir Estudiante</div>
        {modo!=='buscar'&&<button className="btn btn-ghost btn-sm" onClick={reset}>← Empezar de nuevo</button>}
      </header>
      <div className="page-content max-w-3xl">

        {/* BUSCAR */}
        {modo==='buscar'&&(
          <div>
            <div className="grid-2 mb-0">
              <div className="card border-2 border-blue-100">
                <div className="text-2xl mb-1">🔍</div>
                <div className="font-extrabold text-blue-800 text-sm">Estudiante existente</div>
                <div className="text-xs text-blue-600 mt-1">Solo crea la inscripción. No duplica datos personales.</div>
              </div>
              <div className="card border-2 border-green-100">
                <div className="text-2xl mb-1">✨</div>
                <div className="font-extrabold text-green-800 text-sm">Estudiante nuevo</div>
                <div className="text-xs text-green-600 mt-1">Si no se encuentra, se habilita el formulario completo.</div>
              </div>
            </div>
            <div className="card mt-4">
              <div className="card-title">🔍 Buscar estudiante</div>
              <div className="flex gap-3 mb-3">
                <div className="w-36"><label className="label">Buscar por</label>
                  <select className="input" value={busq.tipo} onChange={e=>setBusq(b=>({...b,tipo:e.target.value}))}>
                    <option value="cui">CUI</option><option value="codigo">Código</option><option value="nombre">Nombre</option>
                  </select>
                </div>
                <div className="flex-1"><label className="label">{busq.tipo==='cui'?'Número de CUI':busq.tipo==='codigo'?'Código EST-XXXX':'Nombre Apellido'}</label>
                  <input className="input" value={busq.val} onChange={e=>setBusq(b=>({...b,val:e.target.value}))} onKeyDown={e=>e.key==='Enter'&&buscar()} placeholder={busq.tipo==='cui'?'2456 78901 0101':busq.tipo==='codigo'?'EST-2026-0001':'María García'}/>
                </div>
                <div className="pt-5"><LoadingBtn loading={buscando} className="btn btn-primary" onClick={buscar}>🔍 Buscar</LoadingBtn></div>
              </div>
              {errBusq&&<Alert type="error">{errBusq}</Alert>}
              {resultados.length>0&&(
                <div>
                  <div className="text-sm font-bold text-gray-700 mb-2">✅ {resultados.length} resultado(s) — selecciona el correcto:</div>
                  {resultados.map((e:any)=>(
                    <div key={e.id} onClick={()=>{setEstSel(e);setResultados([]);setModo('encontrado')}}
                      className="border border-gray-100 rounded-xl p-3 mb-2 hover:border-pronea-secondary hover:bg-pronea-light cursor-pointer transition-all">
                      <div className="font-bold text-gray-800">{e.primer_nombre} {e.segundo_nombre} {e.primer_apellido} {e.segundo_apellido}</div>
                      <div className="text-xs text-gray-400 mt-0.5">Código: <b>{e.codigo_estudiante}</b> · CUI: <b>{e.cui_pendiente?'Pendiente':(e.cui??'—')}</b> · Tel: <b>{e.telefono}</b></div>
                      {e.discapacidad?.nombre!=='Ninguna'&&<div className="text-xs text-orange-600 mt-0.5">⚠️ {e.discapacidad?.nombre}</div>}
                      {e.inscripciones?.length>0&&<div className="flex flex-wrap gap-1 mt-1">{e.inscripciones.map((i:any)=><span key={i.id} className={`badge text-xs ${i.estado==='en_curso'?'badge-green':'badge-gray'}`}>{i.etapa?.nombre} · {i.ciclo_escolar} · {i.version_libro==='nuevo'?'📗':'📙'}</span>)}</div>}
                    </div>
                  ))}
                  <div className="flex items-center justify-between pt-2 border-t border-gray-100">
                    <span className="text-xs text-gray-400">¿No es ninguno?</span>
                    <button className="btn btn-ghost btn-sm" onClick={()=>{setResultados([]);setModo('nuevo')}}>✨ Crear como nuevo</button>
                  </div>
                </div>
              )}
              <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-100">
                <span className="text-xs text-gray-400">¿Estudiante completamente nuevo?</span>
                <button className="btn btn-ghost btn-sm" onClick={()=>setModo('nuevo')}>✨ Ingresar nuevo</button>
              </div>
            </div>
          </div>
        )}

        {/* ESTUDIANTE EXISTENTE */}
        {modo==='encontrado'&&estSel&&(
          <div>
            <div className="bg-blue-50 border-2 border-blue-200 rounded-xl p-4 mb-4 flex items-start justify-between">
              <div>
                <div className="text-xs text-blue-500 font-bold uppercase tracking-wide mb-1">✅ Estudiante seleccionado</div>
                <div className="font-extrabold text-blue-900 text-base">{estSel.primer_nombre} {estSel.primer_apellido}</div>
                <div className="text-xs text-blue-700 mt-0.5">Código: <b>{estSel.codigo_estudiante}</b> · CUI: <b>{estSel.cui_pendiente?'Pendiente':(estSel.cui??'—')}</b></div>
              </div>
              <button className="btn btn-ghost btn-sm" onClick={()=>{setModo('buscar');setEstSel(null)}}>✕ Cambiar</button>
            </div>
            {err&&<Alert type="error">{err}</Alert>}
            <div className="card">
              <div className="card-title">📋 Nueva inscripción</div>
              <div className="fgrid2">
                <FormGroup label="Etapa educativa" required>
                  <Select value={insc.etapa_id} onChange={e=>setInsc(i=>({...i,etapa_id:e.target.value}))}>
                    <option value="">— Seleccionar —</option>
                    {ETAPAS_LISTA.map(e=><option key={e.id} value={e.id}>{e.nombre}</option>)}
                  </Select>
                </FormGroup>
                <FormGroup label="Ciclo escolar"><Input type="number" value={insc.ciclo_escolar} onChange={e=>setInsc(i=>({...i,ciclo_escolar:e.target.value}))}/></FormGroup>
                <FormGroup label="Sede (UUID)" required><Input value={insc.sede_id} onChange={e=>setInsc(i=>({...i,sede_id:e.target.value}))} placeholder="UUID de la sede"/></FormGroup>
                <FormGroup label="Modalidad">
                  <Select value={insc.modalidad_id} onChange={e=>setInsc(i=>({...i,modalidad_id:e.target.value}))}>
                    <option value="1">Semipresencial</option><option value="2">A distancia</option><option value="3">En línea</option>
                  </Select>
                </FormGroup>
                <FormGroup label="Sección">
                  <Select value={insc.seccion_id} onChange={e=>setInsc(i=>({...i,seccion_id:e.target.value}))}>
                    <option value="">—</option>{SECC.map((c,idx)=><option key={c} value={idx+1}>{c}</option>)}
                  </Select>
                </FormGroup>
                <FormGroup label="Código SIREEX"><Input value={insc.codigo_sireex} onChange={e=>setInsc(i=>({...i,codigo_sireex:e.target.value}))} placeholder="Opcional — puede asignarse después"/></FormGroup>
              </div>
              <div className="mb-3">
                <label className="label mb-1">Versión del libro <span className="text-red-500">*</span></label>
                <SelectorVersionLibro value={insc.version_libro} onChange={v=>setInsc(i=>({...i,version_libro:v}))}/>
              </div>
              <div className="flex justify-end mt-3">
                <LoadingBtn loading={saving} className="btn btn-success" onClick={guardarExistente}>✅ Crear inscripción</LoadingBtn>
              </div>
            </div>
          </div>
        )}

        {/* NUEVO ESTUDIANTE */}
        {modo==='nuevo'&&(
          <div>
            <div className="bg-green-50 border border-green-200 rounded-xl p-3 mb-4 flex items-center gap-3">
              <span className="text-xl">✨</span>
              <div>
                <div className="font-bold text-green-800 text-sm">Creando nuevo estudiante</div>
                <div className="text-xs text-green-600">Se crearán registros en <code className="bg-green-100 px-1 rounded">usuarios</code> <code className="bg-green-100 px-1 rounded">estudiantes</code> <code className="bg-green-100 px-1 rounded">inscripciones</code></div>
              </div>
            </div>
            <Steps steps={['Datos personales','Inscripción','Documentos']} current={paso-1}/>
            {err&&<Alert type="error">{err}</Alert>}
            <div className="card">
              {/* PASO 1 */}
              {paso===1&&(
                <div>
                  <div className="text-sm font-extrabold text-gray-700 mb-3">Datos personales</div>
                  <div className="fgrid2">
                    <FormGroup label="Primer nombre" required><Input value={per.primer_nombre} onChange={e=>setPer(p=>({...p,primer_nombre:e.target.value}))} placeholder="María"/></FormGroup>
                    <FormGroup label="Segundo nombre"><Input value={per.segundo_nombre} onChange={e=>setPer(p=>({...p,segundo_nombre:e.target.value}))}/></FormGroup>
                    <FormGroup label="Primer apellido" required><Input value={per.primer_apellido} onChange={e=>setPer(p=>({...p,primer_apellido:e.target.value}))} placeholder="García"/></FormGroup>
                    <FormGroup label="Segundo apellido"><Input value={per.segundo_apellido} onChange={e=>setPer(p=>({...p,segundo_apellido:e.target.value}))}/></FormGroup>
                    <FormGroup label="Apellido de casada"><Input value={per.apellido_casada} onChange={e=>setPer(p=>({...p,apellido_casada:e.target.value}))}/></FormGroup>
                    <FormGroup label="Género">
                      <Select value={per.genero} onChange={e=>setPer(p=>({...p,genero:e.target.value}))}>
                        <option value="">—</option><option value="masculino">Masculino</option><option value="femenino">Femenino</option><option value="otro">Otro</option>
                      </Select>
                    </FormGroup>
                    <div className="col-span-2 flex gap-3 items-end">
                      <FormGroup label="CUI (13 dígitos)" required={!per.cui_pendiente} className="flex-1 mb-0">
                        <Input value={per.cui} onChange={e=>setPer(p=>({...p,cui:e.target.value}))} placeholder="2456 78901 0101" disabled={per.cui_pendiente} maxLength={15}/>
                      </FormGroup>
                      <label className="flex items-center gap-2 text-xs font-semibold text-gray-600 cursor-pointer pb-2 whitespace-nowrap">
                        <input type="checkbox" checked={per.cui_pendiente} onChange={e=>setPer(p=>({...p,cui_pendiente:e.target.checked,cui:''}))} className="w-4 h-4"/>Sin CUI
                      </label>
                    </div>
                    <FormGroup label="Fecha nacimiento"><Input type="date" value={per.fecha_nacimiento} onChange={e=>setPer(p=>({...p,fecha_nacimiento:e.target.value}))}/></FormGroup>
                    <FormGroup label="Teléfono" required><Input value={per.telefono} onChange={e=>setPer(p=>({...p,telefono:e.target.value}))} placeholder="5555-1234"/></FormGroup>
                    <FormGroup label="Teléfono alternativo"><Input value={per.telefono_alternativo} onChange={e=>setPer(p=>({...p,telefono_alternativo:e.target.value}))}/></FormGroup>
                    <FormGroup label="Correo electrónico"><Input type="email" value={per.correo} onChange={e=>setPer(p=>({...p,correo:e.target.value}))}/></FormGroup>
                    <FormGroup label="Correo Classroom"><Input type="email" value={per.correo_classroom} onChange={e=>setPer(p=>({...p,correo_classroom:e.target.value}))}/></FormGroup>
                    <FormGroup label="Municipio">
                      <Select value={per.municipio_id} onChange={e=>setPer(p=>({...p,municipio_id:e.target.value}))}>
                        <option value="">—</option>{MUNICIPIOS_SAC.map(m=><option key={m.id} value={m.id}>{m.nombre}</option>)}
                      </Select>
                    </FormGroup>
                    <FormGroup label="Discapacidad">
                      <Select value={per.discapacidad_id} onChange={e=>setPer(p=>({...p,discapacidad_id:e.target.value}))}>
                        {DISC.map(d=><option key={d.id} value={d.id}>{d.n}</option>)}
                      </Select>
                    </FormGroup>
                    <FormGroup label="Dirección"><Input value={per.direccion} onChange={e=>setPer(p=>({...p,direccion:e.target.value}))}/></FormGroup>
                    <FormGroup label="Becado por"><Input value={per.becado_por} onChange={e=>setPer(p=>({...p,becado_por:e.target.value}))} placeholder="MINEDUC, Municipalidad..."/></FormGroup>
                    <div className="col-span-2"><label className="flex items-center gap-2 text-sm font-semibold text-gray-600 cursor-pointer"><input type="checkbox" checked={per.conflicto_ley} onChange={e=>setPer(p=>({...p,conflicto_ley:e.target.checked}))} className="w-4 h-4"/>Conflicto con la Ley</label></div>
                  </div>
                  <div className="flex justify-between mt-4">
                    <button className="btn btn-ghost btn-sm" onClick={()=>setModo('buscar')}>← Volver</button>
                    <button className="btn btn-primary" onClick={()=>{if(!per.primer_nombre||!per.primer_apellido||!per.telefono){setErr('Nombre y teléfono requeridos');return}if(!per.cui_pendiente&&!per.cui){setErr('Ingresa CUI o marca Sin CUI');return}setErr('');setPaso(2)}}>Siguiente →</button>
                  </div>
                </div>
              )}
              {/* PASO 2 */}
              {paso===2&&(
                <div>
                  <div className="text-sm font-extrabold text-gray-700 mb-3">Datos de inscripción</div>
                  <div className="fgrid2">
                    <FormGroup label="Etapa" required><Select value={insc.etapa_id} onChange={e=>setInsc(i=>({...i,etapa_id:e.target.value}))}><option value="">— Seleccionar —</option>{ETAPAS_LISTA.map(e=><option key={e.id} value={e.id}>{e.nombre}</option>)}</Select></FormGroup>
                    <FormGroup label="Ciclo"><Input type="number" value={insc.ciclo_escolar} onChange={e=>setInsc(i=>({...i,ciclo_escolar:e.target.value}))}/></FormGroup>
                    <FormGroup label="Sede (UUID)" required><Input value={insc.sede_id} onChange={e=>setInsc(i=>({...i,sede_id:e.target.value}))} placeholder="UUID"/></FormGroup>
                    <FormGroup label="Modalidad"><Select value={insc.modalidad_id} onChange={e=>setInsc(i=>({...i,modalidad_id:e.target.value}))}><option value="1">Semipresencial</option><option value="2">A distancia</option><option value="3">En línea</option></Select></FormGroup>
                    <FormGroup label="Sección"><Select value={insc.seccion_id} onChange={e=>setInsc(i=>({...i,seccion_id:e.target.value}))}><option value="">—</option>{SECC.map((c,idx)=><option key={c} value={idx+1}>{c}</option>)}</Select></FormGroup>
                    <FormGroup label="Código SIREEX"><Input value={insc.codigo_sireex} onChange={e=>setInsc(i=>({...i,codigo_sireex:e.target.value}))} placeholder="Opcional"/></FormGroup>
                  </div>
                  <div className="mb-3"><label className="label mb-1">Versión del libro *</label><SelectorVersionLibro value={insc.version_libro} onChange={v=>setInsc(i=>({...i,version_libro:v}))}/></div>
                  <div className="flex justify-between mt-4">
                    <button className="btn btn-ghost" onClick={()=>setPaso(1)}>← Anterior</button>
                    <button className="btn btn-primary" onClick={()=>{if(!insc.etapa_id||!insc.sede_id){setErr('Etapa y sede requeridos');return}setErr('');setPaso(3)}}>Siguiente →</button>
                  </div>
                </div>
              )}
              {/* PASO 3 */}
              {paso===3&&(
                <div>
                  <div className="text-sm font-extrabold text-gray-700 mb-2">Documentos</div>
                  <div className="alert alert-i mb-3">📎 URL pública de Google Drive. Tabla: <code>documentos_estudiante</code></div>
                  {docs.map((d,idx)=>(
                    <FormGroup key={d.tipo_documento_id} label={d.label} required={d.req}>
                      <Input type="url" value={d.url} onChange={e=>{const nd=[...docs];nd[idx].url=e.target.value;setDocs(nd)}} placeholder="https://drive.google.com/..."/>
                    </FormGroup>
                  ))}
                  <div className="bg-gray-50 rounded-xl p-3 text-xs text-gray-600 mb-3">
                    <b>Resumen:</b> {per.primer_nombre} {per.primer_apellido} · {ETAPAS_LISTA.find(e=>e.id===parseInt(insc.etapa_id))?.nombre} · <span className={`badge ${insc.version_libro==='nuevo'?'badge-blue':'badge-orange'}`}>{insc.version_libro==='nuevo'?'📗 Nuevo':'📙 Viejo'}</span>
                  </div>
                  <div className="flex justify-between">
                    <button className="btn btn-ghost" onClick={()=>setPaso(2)}>← Anterior</button>
                    <LoadingBtn loading={saving} className="btn btn-success" onClick={guardarNuevo}>✅ Guardar inscripción</LoadingBtn>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
