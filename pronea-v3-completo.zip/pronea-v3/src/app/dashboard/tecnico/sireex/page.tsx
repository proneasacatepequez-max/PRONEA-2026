'use client'
// src/app/dashboard/tecnico/sireex/page.tsx
import { useState, useEffect } from 'react'
import { Badge, BadgeEstado, Modal, FormGroup, Input, Select, Alert, LoadingBtn, Spinner, Empty } from '@/components/ui'
import { ETAPAS_LISTA } from '@/types'

export default function TecnicoSireexPage() {
  const [grupos, setGrupos] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [modalNuevo, setModalNuevo] = useState(false)
  const [modalEst, setModalEst] = useState<any>(null)   // grupo seleccionado para ver estudiantes
  const [estudiantes, setEstudiantes] = useState<any[]>([])
  const [saving, setSaving] = useState(false)
  const [err, setErr] = useState('')
  const [formG, setFormG] = useState({ etapa_id:'', sede_id:'', ciclo_escolar:'2026', nombre:'', codigo:'' })
  const [buscarEst, setBuscarEst] = useState('')   // CUI o código para agregar estudiante
  const [agregando, setAgregando] = useState(false)

  const cargar = async () => {
    setLoading(true)
    const d = await fetch('/api/sireex/grupos?ciclo=2026').then(r=>r.json())
    setGrupos(Array.isArray(d)?d:[])
    setLoading(false)
  }
  useEffect(()=>{ cargar() },[])

  const cargarEstudiantes = async (grupo: any) => {
    setModalEst(grupo)
    const d = await fetch(`/api/sireex/${grupo.id}/estudiantes`).then(r=>r.json())
    setEstudiantes(Array.isArray(d)?d:[])
  }

  const crearGrupo = async () => {
    if (!formG.etapa_id||!formG.sede_id) { setErr('Etapa y sede requeridos'); return }
    setSaving(true); setErr('')
    const res = await fetch('/api/sireex/grupos',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...formG,etapa_id:parseInt(formG.etapa_id),ciclo_escolar:parseInt(formG.ciclo_escolar)})})
    const d = await res.json()
    if (!res.ok) { setErr(d.error??'Error'); setSaving(false); return }
    setModalNuevo(false); setFormG({etapa_id:'',sede_id:'',ciclo_escolar:'2026',nombre:'',codigo:''}); cargar()
    setSaving(false)
  }

  const agregarEstudiante = async () => {
    if (!buscarEst||!modalEst) return
    setAgregando(true)
    // Buscar inscripción por CUI o código
    const b = await fetch(`/api/estudiantes/buscar?${buscarEst.includes('-')?'codigo':'cui'}=${buscarEst}`).then(r=>r.json())
    if (!b.encontrado||!b.estudiantes?.[0]) { alert('Estudiante no encontrado'); setAgregando(false); return }
    const est = b.estudiantes[0]
    const insc = est.inscripciones?.find((i:any)=>i.ciclo_escolar===2026&&i.estado==='en_curso')
    if (!insc) { alert('No tiene inscripción activa en 2026'); setAgregando(false); return }
    const res = await fetch(`/api/sireex/${modalEst.id}/estudiantes`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({inscripcion_id:insc.id})})
    const d = await res.json()
    if (res.status===409) { alert('El estudiante ya está en este grupo'); setAgregando(false); return }
    if (!res.ok) { alert(d.error??'Error'); setAgregando(false); return }
    setBuscarEst(''); cargarEstudiantes(modalEst)
    setAgregando(false)
  }

  const exportar = async (grupo: any) => {
    if (grupo.estado==='abierto') {
      if (!confirm(`El grupo "${grupo.codigo}" está abierto. ¿Deseas cerrarlo y exportar?`)) return
    }
    window.open(`/api/sireex/${grupo.id}/exportar`, '_blank')
  }

  return (
    <div className="animate-page">
      <header className="topbar">
        <div className="page-title">📤 Grupos SIREEX</div>
        <button className="btn btn-primary" onClick={()=>setModalNuevo(true)}>＋ Nuevo grupo</button>
      </header>
      <div className="page-content">
        <div className="alert alert-i mb-4">
          <div>
            <b>¿Cómo funciona?</b> Crea un grupo SIREEX → agrega estudiantes mientras esté <b>abierto</b> →
            cuando tengan todos el código SIREEX, ciérralo y expórtalo a CSV.
            El código SIREEX <b>no es obligatorio al inscribir</b> pero sí para exportar.
          </div>
        </div>

        {loading ? <Spinner/> : grupos.length===0 ? <Empty msg="No hay grupos SIREEX creados aún"/> : (
          <div className="grid gap-4">
            {grupos.map((g:any)=>(
              <div key={g.id} className="card">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className="font-extrabold text-gray-800 text-base">{g.codigo}</div>
                    {g.nombre&&<div className="text-sm text-gray-500">{g.nombre}</div>}
                    <div className="text-xs text-gray-400 mt-0.5">
                      {g.etapa?.nombre} · {g.sede?.nombre} · Ciclo {g.ciclo_escolar} · Técnico: {g.tecnico?.primer_nombre} {g.tecnico?.primer_apellido}
                    </div>
                  </div>
                  <BadgeEstado e={g.estado}/>
                </div>
                <div className="flex items-center justify-between">
                  <div className="text-sm text-gray-600">
                    <b>{g._count?.estudiantes??0}</b> estudiantes
                    {g.fecha_cierre&&<span className="ml-2 text-gray-400">· Cerrado: {new Date(g.fecha_cierre).toLocaleDateString('es-GT')}</span>}
                  </div>
                  <div className="flex gap-2">
                    <button className="btn btn-ghost btn-sm" onClick={()=>cargarEstudiantes(g)}>👁️ Ver estudiantes</button>
                    {g.estado!=='exportado'&&<button className="btn btn-primary btn-sm" onClick={()=>exportar(g)}>📥 Exportar CSV</button>}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Modal nuevo grupo */}
      <Modal open={modalNuevo} onClose={()=>setModalNuevo(false)} title="＋ Nuevo Grupo SIREEX"
        footer={<><button className="btn btn-ghost" onClick={()=>setModalNuevo(false)}>Cancelar</button><LoadingBtn loading={saving} className="btn btn-primary" onClick={crearGrupo}>💾 Crear grupo</LoadingBtn></>}>
        {err&&<Alert type="error">{err}</Alert>}
        <FormGroup label="Etapa" required>
          <Select value={formG.etapa_id} onChange={e=>setFormG(f=>({...f,etapa_id:e.target.value}))}>
            <option value="">— Seleccionar —</option>{ETAPAS_LISTA.map(e=><option key={e.id} value={e.id}>{e.nombre}</option>)}
          </Select>
        </FormGroup>
        <FormGroup label="Sede (UUID)" required><Input value={formG.sede_id} onChange={e=>setFormG(f=>({...f,sede_id:e.target.value}))} placeholder="UUID de la sede"/></FormGroup>
        <FormGroup label="Ciclo escolar"><Input type="number" value={formG.ciclo_escolar} onChange={e=>setFormG(f=>({...f,ciclo_escolar:e.target.value}))}/></FormGroup>
        <FormGroup label="Nombre descriptivo (opcional)"><Input value={formG.nombre} onChange={e=>setFormG(f=>({...f,nombre:e.target.value}))} placeholder="Ej: Primaria Antigua Guatemala"/></FormGroup>
        <FormGroup label="Código personalizado (opcional)" hint="Si se deja vacío se genera automáticamente">
          <Input value={formG.codigo} onChange={e=>setFormG(f=>({...f,codigo:e.target.value}))} placeholder="SIREEX-2026-001"/>
        </FormGroup>
      </Modal>

      {/* Modal estudiantes del grupo */}
      <Modal open={!!modalEst} onClose={()=>setModalEst(null)} title={`Estudiantes: ${modalEst?.codigo}`} size="lg"
        footer={<button className="btn btn-ghost" onClick={()=>setModalEst(null)}>Cerrar</button>}>
        {modalEst?.estado==='abierto'&&(
          <div className="mb-4">
            <div className="text-xs font-bold text-gray-600 mb-1">Agregar estudiante (CUI o código)</div>
            <div className="flex gap-2">
              <Input value={buscarEst} onChange={e=>setBuscarEst(e.target.value)} placeholder="CUI o EST-2026-XXXX" className="flex-1" onKeyDown={e=>e.key==='Enter'&&agregarEstudiante()}/>
              <LoadingBtn loading={agregando} className="btn btn-primary btn-sm" onClick={agregarEstudiante}>Agregar</LoadingBtn>
            </div>
          </div>
        )}
        {estudiantes.length===0
          ? <Empty msg="Sin estudiantes en este grupo"/>
          : <div className="tbl-wrap"><table className="tbl">
              <thead><tr><th>Código</th><th>Nombre</th><th>Código SIREEX</th><th>Versión libro</th><th>Estado</th><th>Nota final</th></tr></thead>
              <tbody>
                {estudiantes.map((r:any)=>{
                  const i=r.inscripcion,e=i?.estudiante,re=i?.resumen_etapa
                  return (
                    <tr key={r.id??i?.id}>
                      <td className="font-mono text-xs">{e?.codigo_estudiante}</td>
                      <td className="font-semibold">{e?.primer_nombre} {e?.primer_apellido}</td>
                      <td>{i?.codigo_sireex?<span className="badge badge-blue">{i.codigo_sireex}</span>:<span className="badge badge-yellow">⚠ Sin código</span>}</td>
                      <td><span className={`badge ${i?.version_libro==='nuevo'?'badge-blue':'badge-orange'}`}>{i?.version_libro==='nuevo'?'📗':'📙'}</span></td>
                      <td><BadgeEstado e={i?.estado??'en_curso'}/></td>
                      <td className={`font-bold ${re?.nota_final_etapa?(re.nota_final_etapa>=60?'text-green-600':'text-red-600'):'text-gray-400'}`}>{re?.nota_final_etapa?`${re.nota_final_etapa}%`:'—'}</td>
                    </tr>
                  )
                })}
              </tbody>
            </table></div>
        }
      </Modal>
    </div>
  )
}
