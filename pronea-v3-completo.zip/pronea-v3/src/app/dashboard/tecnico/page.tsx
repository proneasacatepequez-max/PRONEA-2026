// src/app/dashboard/tecnico/page.tsx
import { redirect } from 'next/navigation'
import { getSession } from '@/lib/auth'
import { supabaseAdmin } from '@/lib/supabase'
import Link from 'next/link'

export default async function TecnicoDashboard() {
  const s = await getSession()
  if (!s || s.rol !== 'tecnico') redirect('/login')

  const { data: tec } = await supabaseAdmin
    .from('tecnicos')
    .select('id,primer_nombre,primer_apellido,codigo_tecnico')
    .eq('usuario_id', s.sub).single()
  if (!tec) redirect('/login')

  const [
    { count: total },
    { count: listos },
    { count: riesgo },
    { count: gruposAbiertos },
  ] = await Promise.all([
    supabaseAdmin.from('inscripciones').select('*',{count:'exact',head:true}).eq('tecnico_id',tec.id).eq('ciclo_escolar',2026).eq('estado','en_curso'),
    supabaseAdmin.from('resumen_libro').select('inscripciones!inner(*)',{count:'exact',head:true}).eq('inscripciones.tecnico_id',tec.id).eq('estado','listo_validar'),
    supabaseAdmin.from('resumen_libro').select('inscripciones!inner(*)',{count:'exact',head:true}).eq('inscripciones.tecnico_id',tec.id).lt('nota_final',45),
    supabaseAdmin.from('grupos_sireex').select('*',{count:'exact',head:true}).eq('tecnico_id',tec.id).eq('estado','abierto').eq('ciclo_escolar',2026),
  ])

  const { data: porVersion } = await supabaseAdmin.from('inscripciones')
    .select('version_libro').eq('tecnico_id',tec.id).eq('ciclo_escolar',2026)
  const vCount = { nuevo:0, viejo:0 }
  porVersion?.forEach((i:any)=>{ vCount[i.version_libro as 'nuevo'|'viejo']++ })

  const { data: ultimas } = await supabaseAdmin.from('inscripciones')
    .select('id,version_libro,fecha_inscripcion,tiene_ajuste_discapacidad,etapa:etapas(nombre),estudiante:estudiantes(primer_nombre,primer_apellido,codigo_estudiante)')
    .eq('tecnico_id',tec.id).eq('ciclo_escolar',2026)
    .order('creado_en',{ascending:false}).limit(5)

  const hoy = new Date().toLocaleDateString('es-GT',{weekday:'long',year:'numeric',month:'long',day:'numeric'})

  return (
    <div className="animate-page">
      <header className="topbar">
        <div>
          <div className="page-title">Hola, {tec.primer_nombre} 👋</div>
          <div className="text-xs text-gray-400">Código: {tec.codigo_tecnico??'—'}</div>
        </div>
        <div className="text-sm text-gray-400">{hoy}</div>
      </header>
      <div className="page-content">
        <div className="grid-4">
          <div className="stat-card blue"><div className="text-3xl mb-1">🎓</div><div className="text-3xl font-extrabold text-gray-800">{total??0}</div><div className="text-sm text-gray-500 font-semibold">Mis estudiantes</div></div>
          <div className="stat-card green"><div className="text-3xl mb-1">✅</div><div className="text-3xl font-extrabold text-gray-800">{listos??0}</div><div className="text-sm text-gray-500 font-semibold">Listos para validar</div></div>
          <div className="stat-card red"><div className="text-3xl mb-1">⚠️</div><div className="text-3xl font-extrabold text-gray-800">{riesgo??0}</div><div className="text-sm text-gray-500 font-semibold">En riesgo (&lt;45%)</div></div>
          <div className="stat-card yellow"><div className="text-3xl mb-1">📤</div><div className="text-3xl font-extrabold text-gray-800">{gruposAbiertos??0}</div><div className="text-sm text-gray-500 font-semibold">Grupos SIREEX abiertos</div></div>
        </div>

        <div className="grid-2">
          {/* Versión libros */}
          <div className="card">
            <div className="card-title">📚 Mis estudiantes por versión de libro</div>
            <div className="flex gap-3">
              <div className="flex-1 bg-blue-50 rounded-xl p-4 text-center">
                <div className="text-3xl font-extrabold text-blue-700">{vCount.nuevo}</div>
                <div className="text-sm font-bold text-blue-600 mt-1">📗 Libro Nuevo</div>
              </div>
              <div className="flex-1 bg-orange-50 rounded-xl p-4 text-center">
                <div className="text-3xl font-extrabold text-orange-700">{vCount.viejo}</div>
                <div className="text-sm font-bold text-orange-600 mt-1">📙 Libro Viejo</div>
                <div className="text-xs text-orange-400 mt-0.5">Finalizando</div>
              </div>
            </div>
            {vCount.viejo > 0 && (
              <div className="mt-3 text-xs bg-orange-50 text-orange-700 p-2 rounded-lg font-semibold">
                ⚠️ {vCount.viejo} estudiante(s) con libro viejo. Puedes cambiarlos desde su perfil.
              </div>
            )}
          </div>

          {/* Acciones rápidas */}
          <div className="card">
            <div className="card-title">⚡ Acciones rápidas</div>
            <div className="grid grid-cols-2 gap-2">
              {[
                {href:'/dashboard/tecnico/inscribir',  icon:'➕', label:'Inscribir estudiante', cls:'btn-primary'},
                {href:'/dashboard/tecnico/notas',      icon:'📝', label:'Registrar notas',     cls:'btn-success'},
                {href:'/dashboard/tecnico/sireex',     icon:'📤', label:'Grupos SIREEX',       cls:'btn-ghost'},
                {href:'/dashboard/tecnico/escalas',    icon:'📄', label:'Generar escala PDF',  cls:'btn-ghost'},
                {href:'/dashboard/tecnico/estudiantes',icon:'🎓', label:'Ver estudiantes',     cls:'btn-ghost'},
                {href:'/dashboard/tecnico/recursos',   icon:'🎬', label:'Recursos apoyo',      cls:'btn-ghost'},
              ].map(({href,icon,label,cls})=>(
                <Link key={href} href={href} className={`btn ${cls} justify-center text-xs py-2.5`}>
                  <span>{icon}</span><span>{label}</span>
                </Link>
              ))}
            </div>
          </div>
        </div>

        {/* Últimas inscripciones */}
        <div className="card">
          <div className="card-title">
            🕐 Últimas inscripciones
            <Link href="/dashboard/tecnico/estudiantes" className="text-xs text-pronea-secondary hover:underline">Ver todos</Link>
          </div>
          {(!ultimas||ultimas.length===0)
            ? <div className="text-sm text-gray-400 text-center py-6">Sin inscripciones registradas aún</div>
            : <div className="tbl-wrap"><table className="tbl">
                <thead><tr><th>Estudiante</th><th>Código</th><th>Etapa</th><th>Versión libro</th><th>Ajuste disc.</th><th>Fecha</th><th></th></tr></thead>
                <tbody>
                  {ultimas.map((i:any)=>(
                    <tr key={i.id}>
                      <td className="font-bold">{(i.estudiante as any)?.primer_nombre} {(i.estudiante as any)?.primer_apellido}</td>
                      <td className="text-xs text-gray-400 font-mono">{(i.estudiante as any)?.codigo_estudiante}</td>
                      <td>{(i.etapa as any)?.nombre}</td>
                      <td><span className={`badge ${i.version_libro==='nuevo'?'badge-blue':'badge-orange'}`}>{i.version_libro==='nuevo'?'📗 Nuevo':'📙 Viejo'}</span></td>
                      <td>{i.tiene_ajuste_discapacidad?<span className="badge badge-purple">♿ Sí</span>:<span className="text-gray-300">—</span>}</td>
                      <td className="text-xs text-gray-400">{new Date(i.fecha_inscripcion).toLocaleDateString('es-GT')}</td>
                      <td><Link href={`/dashboard/tecnico/notas?id=${i.id}`} className="btn btn-primary btn-xs">📝 Notas</Link></td>
                    </tr>
                  ))}
                </tbody>
              </table></div>
          }
        </div>
      </div>
    </div>
  )
}
