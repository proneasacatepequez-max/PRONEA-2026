'use client'
// src/app/dashboard/estudiante/recursos/page.tsx
import { useState, useEffect } from 'react'
import { Spinner, Empty } from '@/components/ui'

const TIPO_ICONS: Record<string,string> = {
  video_youtube:'▶️', video_drive:'🎬', pdf_drive:'📕', documento_word:'📄',
  libro_digital:'📚', formulario:'📋', imagen:'🖼️', audio:'🎧', enlace_web:'🌐', otro:'🔗'
}

export default function RecursosEstudiantePage() {
  const [recursos, setRecursos] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [filtro, setFiltro] = useState<string>('')
  const categorias = [...new Set(recursos.map(r=>r.categoria?.nombre).filter(Boolean))]
  const filtered = filtro ? recursos.filter(r=>r.categoria?.nombre===filtro) : recursos

  useEffect(()=>{
    fetch('/api/recursos').then(r=>r.json()).then(d=>setRecursos(Array.isArray(d)?d:[])).finally(()=>setLoading(false))
  },[])

  if (loading) return <div className="animate-page"><header className="topbar"><div className="page-title">🎬 Recursos de Apoyo</div></header><div className="page-content"><Spinner/></div></div>

  return (
    <div className="animate-page">
      <header className="topbar"><div className="page-title">🎬 Recursos de Apoyo</div></header>
      <div className="page-content">
        {/* Filtros */}
        {categorias.length>0&&(
          <div className="flex gap-2 flex-wrap mb-4">
            <button className={`btn btn-sm ${!filtro?'btn-primary':'btn-ghost'}`} onClick={()=>setFiltro('')}>Todos</button>
            {categorias.map(c=>(
              <button key={c} className={`btn btn-sm ${filtro===c?'btn-primary':'btn-ghost'}`} onClick={()=>setFiltro(c!)}>{c}</button>
            ))}
          </div>
        )}

        {filtered.length===0
          ? <Empty icon="🎬" msg="No hay recursos disponibles para tu etapa"/>
          : (
            <div className="grid gap-4 grid-cols-1 md:grid-cols-2">
              {filtered.map((r:any)=>(
                <div key={r.id} className={`card hover:border-pronea-secondary transition-all cursor-pointer ${r.destacado?'border-2 border-pronea-secondary':''}`}
                  onClick={()=>window.open(r.url,'_blank')}>
                  <div className="flex items-start gap-3">
                    <div className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl flex-shrink-0"
                      style={{background:r.categoria?.color?`${r.categoria.color}20`:'#E9F1F9'}}>
                      {TIPO_ICONS[r.tipo_contenido??'']??'🔗'}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-bold text-gray-800 text-sm leading-tight">{r.titulo}</div>
                      {r.descripcion&&<div className="text-xs text-gray-500 mt-0.5 line-clamp-2">{r.descripcion}</div>}
                      <div className="flex flex-wrap gap-1 mt-2">
                        {r.categoria&&<span className="badge badge-blue text-[10px]">{r.categoria.nombre}</span>}
                        {r.etapa&&<span className="badge badge-gray text-[10px]">{r.etapa.nombre}</span>}
                        {r.area&&<span className="badge badge-gray text-[10px]">{r.area.nombre}</span>}
                        {r.duracion_minutos&&<span className="badge badge-gray text-[10px]">⏱ {r.duracion_minutos} min</span>}
                        {r.destacado&&<span className="badge badge-yellow text-[10px]">⭐ Destacado</span>}
                      </div>
                    </div>
                    <div className="text-pronea-secondary text-sm">→</div>
                  </div>
                </div>
              ))}
            </div>
          )
        }
      </div>
    </div>
  )
}
