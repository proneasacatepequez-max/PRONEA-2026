// src/app/dashboard/director/page.tsx
import { redirect } from 'next/navigation'
import { getSession } from '@/lib/auth'
import { supabaseAdmin } from '@/lib/supabase'
import Link from 'next/link'

export default async function DirectorDashboard() {
  const s = await getSession(); if (!s||s.rol!=='director') redirect('/login')
  const { data: dir } = await supabaseAdmin.from('directores')
    .select('id,primer_nombre,primer_apellido,sede_id,sede:sedes(nombre)').eq('usuario_id',s.sub).single()
  if (!dir) redirect('/login')
  const sId = dir.sede_id
  const [{ count:est },{ count:tec }] = await Promise.all([
    supabaseAdmin.from('inscripciones').select('*',{count:'exact',head:true}).eq('sede_id',sId).eq('ciclo_escolar',2026).eq('estado','en_curso'),
    supabaseAdmin.from('tecnico_sedes').select('*',{count:'exact',head:true}).eq('sede_id',sId).eq('activo',true),
  ])
  const { data: pv } = await supabaseAdmin.from('inscripciones').select('version_libro').eq('sede_id',sId).eq('ciclo_escolar',2026)
  const vc = {nuevo:0,viejo:0}; pv?.forEach((i:any)=>{ vc[i.version_libro as 'nuevo'|'viejo']++ })
  return (
    <div className="animate-page">
      <header className="topbar"><div><div className="page-title">Director — {(dir.sede as any)?.nombre}</div><div className="text-xs text-gray-400">{dir.primer_nombre} {dir.primer_apellido}</div></div></header>
      <div className="page-content">
        <div className="grid-4">
          <div className="stat-card blue"><div className="text-3xl mb-1">🎓</div><div className="text-3xl font-extrabold text-gray-800">{est??0}</div><div className="text-sm text-gray-500 font-semibold">Estudiantes</div></div>
          <div className="stat-card green"><div className="text-3xl mb-1">👨‍🏫</div><div className="text-3xl font-extrabold text-gray-800">{tec??0}</div><div className="text-sm text-gray-500 font-semibold">Técnicos</div></div>
          <div className="stat-card blue"><div className="text-3xl mb-1">📗</div><div className="text-3xl font-extrabold text-blue-700">{vc.nuevo}</div><div className="text-sm text-gray-500 font-semibold">Libro Nuevo</div></div>
          <div className="stat-card yellow"><div className="text-3xl mb-1">📙</div><div className="text-3xl font-extrabold text-orange-600">{vc.viejo}</div><div className="text-sm text-gray-500 font-semibold">Libro Viejo</div></div>
        </div>
        <div className="card">
          <div className="card-title">⚡ Acciones</div>
          <div className="grid grid-cols-3 gap-3">
            <Link href="/dashboard/director/tecnicos" className="btn btn-primary justify-center">👨‍🏫 Mis Técnicos</Link>
            <Link href="/dashboard/director/estudiantes" className="btn btn-ghost justify-center">🎓 Estudiantes</Link>
            <Link href="/dashboard/director/reportes" className="btn btn-ghost justify-center">📈 Reportes</Link>
          </div>
        </div>
      </div>
    </div>
  )
}
