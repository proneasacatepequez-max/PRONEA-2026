// src/app/api/sireex/[id]/exportar/route.ts
// GET — exportar CSV del grupo (usa v_exportacion_grupo_sireex)
import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'
import { getSession, err } from '@/lib/auth'

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const s = await getSession(req); if (!s) return err('No autorizado',401)
  if (!['administrador','coordinador_digeex','tecnico','director'].includes(s.rol))
    return err('Sin permiso',403)

  // Usar la vista de exportación (creada en migración v3)
  const { data, error } = await supabaseAdmin.from('v_exportacion_grupo_sireex')
    .select('*').eq('grupo_sireex_codigo', params.id)

  // Si la vista no existe aún, fallback a query directa
  const registros = data?.length ? data : await fetchDirecto(params.id)

  if (!registros?.length) return err('El grupo no tiene estudiantes',404)

  const headers = [
    'grupo_sireex','codigo_estudiante','nombre_completo','cui','discapacidad',
    'etapa','sede','tecnico_responsable','codigo_sireex_individual',
    'version_libro','tiene_ajuste','nota_libro_1','nota_libro_2',
    'nota_final_etapa','calificacion','promovido','validado_digeex'
  ]
  const rows = registros.map((r:any)=>[
    r.grupo_sireex_codigo??r.codigo, r.codigo_estudiante, r.nombre_completo,
    r.cui??'', r.discapacidad??'Ninguna', r.etapa, r.sede,
    r.tecnico_responsable, r.codigo_sireex_individual??'',
    r.version_libro, r.tiene_ajuste_discapacidad?'SÍ':'NO',
    r.nota_libro_1??'', r.nota_libro_2??'', r.nota_final_etapa??'',
    r.calificacion_cualitativa??'', r.promovido?'PROMOVIDO':'NO PROMOVIDO',
    r.validado_digeex?'SÍ':'NO'
  ].map(v=>`"${String(v).replace(/"/g,'""')}"`)join(','))

  const csv = '\uFEFF'+[headers.join(','), ...rows].join('\n') // BOM para Excel
  const fecha = new Date().toISOString().split('T')[0]

  // Marcar como exportado
  await supabaseAdmin.from('grupos_sireex').update({
    estado:'exportado', fecha_exportacion:new Date().toISOString(), exportado_por:s.sub
  }).eq('id',params.id)

  await supabaseAdmin.from('grupos_sireex_historial').insert({
    grupo_sireex_id:params.id, accion:'EXPORTADO', usuario_id:s.sub,
    detalle:`CSV exportado: ${registros.length} estudiantes`
  })

  return new NextResponse(csv, {
    headers: {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename="sireex_${params.id}_${fecha}.csv"`,
    }
  })
}

async function fetchDirecto(grupoId: string) {
  const { data } = await supabaseAdmin.from('inscripcion_grupo_sireex')
    .select(`
      inscripcion:inscripciones(id,codigo_sireex,version_libro,tiene_ajuste_discapacidad,
        estudiante:estudiantes(codigo_estudiante,primer_nombre,segundo_nombre,primer_apellido,segundo_apellido,cui,cui_pendiente,
          discapacidad:tipos_discapacidad(nombre)),
        etapa:etapas(nombre),
        sede:sedes(nombre),
        tecnico:tecnicos(primer_nombre,primer_apellido),
        resumen_etapa(nota_libro_1,nota_libro_2,nota_final_etapa,calificacion_cualitativa,promovido,validado_digeex)
      )`)
    .eq('grupo_sireex_id',grupoId)

  return (data??[]).map((r:any)=>{
    const i=r.inscripcion, e=i?.estudiante, re=i?.resumen_etapa
    return {
      grupo_sireex_codigo:grupoId,
      codigo_estudiante:e?.codigo_estudiante??'',
      nombre_completo:[e?.primer_nombre,e?.segundo_nombre,e?.primer_apellido,e?.segundo_apellido].filter(Boolean).join(' '),
      cui:e?.cui_pendiente?'Pendiente':(e?.cui??''),
      discapacidad:(e?.discapacidad as any)?.nombre??'Ninguna',
      etapa:(i?.etapa as any)?.nombre??'', sede:(i?.sede as any)?.nombre??'',
      tecnico_responsable:[(i?.tecnico as any)?.primer_nombre,(i?.tecnico as any)?.primer_apellido].filter(Boolean).join(' '),
      codigo_sireex_individual:i?.codigo_sireex??'',
      version_libro:i?.version_libro??'',
      tiene_ajuste_discapacidad:i?.tiene_ajuste_discapacidad??false,
      nota_libro_1:(re as any)?.nota_libro_1??'',
      nota_libro_2:(re as any)?.nota_libro_2??'',
      nota_final_etapa:(re as any)?.nota_final_etapa??'',
      calificacion_cualitativa:(re as any)?.calificacion_cualitativa??'',
      promovido:(re as any)?.promovido,
      validado_digeex:(re as any)?.validado_digeex,
    }
  })
}
