// src/app/api/sireex/[id]/estudiantes/route.ts
// GET  — estudiantes del grupo
// POST — agregar inscripción al grupo
import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'
import { getSession, ok, err } from '@/lib/auth'

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const s = await getSession(req); if (!s) return err('No autorizado',401)
  const { data, error } = await supabaseAdmin.from('inscripcion_grupo_sireex')
    .select(`asignado_en,
      inscripcion:inscripciones(id,ciclo_escolar,estado,codigo_sireex,version_libro,
        estudiante:estudiantes(id,codigo_estudiante,primer_nombre,segundo_nombre,primer_apellido,segundo_apellido,cui,cui_pendiente,
          discapacidad:tipos_discapacidad(nombre)),
        etapa:etapas(nombre),
        resumen_etapa(nota_final_etapa,promovido,validado_digeex)
      )`)
    .eq('grupo_sireex_id', params.id)
  if (error) return err(error.message,500)
  return ok(data??[])
}

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const s = await getSession(req); if (!s) return err('No autorizado',401)
  const { inscripcion_id } = await req.json()
  if (!inscripcion_id) return err('inscripcion_id requerido')

  const { error } = await supabaseAdmin.from('inscripcion_grupo_sireex')
    .insert({ inscripcion_id, grupo_sireex_id:params.id, asignado_por:s.sub })
  if (error) {
    if (error.code==='23505') return err('Este estudiante ya está en el grupo',409)
    // El trigger fn_validar_grupo_abierto lanzará error si el grupo está cerrado
    return err(error.message, 500)
  }
  return ok({ ok:true })
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  const s = await getSession(req); if (!s) return err('No autorizado',401)
  const { inscripcion_id } = await req.json()
  const { error } = await supabaseAdmin.from('inscripcion_grupo_sireex')
    .delete().eq('grupo_sireex_id',params.id).eq('inscripcion_id',inscripcion_id)
  if (error) return err(error.message,500)
  return ok({ ok:true })
}
