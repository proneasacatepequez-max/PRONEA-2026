// src/app/api/estudiantes/[id]/inscribir/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'
import { getSession, ok, err } from '@/lib/auth'

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const s = await getSession(req); if (!s) return err('No autorizado',401)
  const b = await req.json()
  if (!b.etapa_id||!b.sede_id||!b.ciclo_escolar) return err('etapa_id, sede_id, ciclo_escolar requeridos')
  if (!['viejo','nuevo'].includes(b.version_libro??'nuevo')) return err('version_libro inválido')

  const { data: est } = await supabaseAdmin.from('estudiantes')
    .select('id,codigo_estudiante,primer_nombre,primer_apellido').eq('id',params.id).single()
  if (!est) return err('Estudiante no encontrado',404)

  // Verificar UNIQUE(estudiante_id, etapa_id, ciclo_escolar)
  const { data: existe } = await supabaseAdmin.from('inscripciones')
    .select('id,estado,version_libro,etapa:etapas(nombre)')
    .eq('estudiante_id',params.id).eq('etapa_id',b.etapa_id).eq('ciclo_escolar',b.ciclo_escolar).single()

  if (existe) {
    return NextResponse.json({
      error:'DUPLICADO',
      message:`${est.primer_nombre} ${est.primer_apellido} ya está inscrito en esta etapa para el ciclo ${b.ciclo_escolar}.`,
      inscripcion_existente:{ id:existe.id, estado:existe.estado, version_libro:existe.version_libro, etapa:(existe.etapa as any)?.nombre }
    }, { status:409 })
  }

  const { data: insc, error } = await supabaseAdmin.from('inscripciones').insert({
    estudiante_id:params.id, etapa_id:b.etapa_id, tecnico_id:b.tecnico_id??s.sub,
    sede_id:b.sede_id, modalidad_id:b.modalidad_id??null, seccion_id:b.seccion_id??null,
    ciclo_escolar:b.ciclo_escolar, repite_etapa:b.repite_etapa??false, estado:'en_curso',
    estado_classroom:b.estado_classroom??null, codigo_sireex:b.codigo_sireex??null,
    version_libro:b.version_libro??'nuevo', observaciones:b.observaciones??null, creado_por:s.sub,
  }).select('id').single()

  if (error) return err(error.message, 500)

  await supabaseAdmin.from('auditoria').insert({
    usuario_id:s.sub, accion:'INSCRIPCION_EXISTENTE', tabla_afectada:'inscripciones',
    registro_id:insc.id, datos_nuevos:{ estudiante_id:params.id, etapa_id:b.etapa_id, version_libro:b.version_libro }
  })

  return ok({ ok:true, inscripcion_id:insc.id, codigo_estudiante:est.codigo_estudiante,
    estudiante:`${est.primer_nombre} ${est.primer_apellido}` }, 201)
}
