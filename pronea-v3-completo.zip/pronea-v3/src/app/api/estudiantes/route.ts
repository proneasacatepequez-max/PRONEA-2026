// src/app/api/estudiantes/route.ts
// GET  — lista con filtros (tecnico_id, sede_id, etapa_id, version_libro, buscar)
// POST — crear nuevo estudiante + inscripción
import { NextRequest } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'
import { getSession, ok, err } from '@/lib/auth'
import bcrypt from 'bcryptjs'

export async function GET(req: NextRequest) {
  const s = await getSession(req); if (!s) return err('No autorizado',401)
  const p = req.nextUrl.searchParams
  const tecnico_id    = s.rol==='tecnico' ? s.sub : (p.get('tecnico_id')??undefined)
  const sede_id       = p.get('sede_id')??undefined
  const etapa_id      = p.get('etapa_id')??undefined
  const version_libro = p.get('version_libro')??undefined
  const estado        = p.get('estado')??undefined
  const buscar        = p.get('buscar')??undefined
  const ciclo         = p.get('ciclo')??'2026'
  const page          = parseInt(p.get('page')??'1')
  const limit         = parseInt(p.get('limit')??'50')

  let q = supabaseAdmin.from('inscripciones')
    .select(`id,ciclo_escolar,estado,version_libro,tiene_ajuste_discapacidad,fecha_inscripcion,codigo_sireex,
      etapa:etapas(id,nombre,codigo,nivel),
      tecnico:tecnicos(id,primer_nombre,primer_apellido,codigo_tecnico),
      sede:sedes(id,nombre),
      modalidad:modalidades(nombre),
      seccion:secciones(codigo),
      estudiante:estudiantes(id,codigo_estudiante,primer_nombre,segundo_nombre,primer_apellido,segundo_apellido,
        cui,cui_pendiente,telefono,correo,discapacidad_id,activo,
        discapacidad:tipos_discapacidad(nombre,codigo))
    `,{count:'exact'})
    .eq('ciclo_escolar', parseInt(ciclo))
    .range((page-1)*limit, page*limit-1)

  if (tecnico_id) q = q.eq('tecnico_id', tecnico_id)
  if (sede_id)    q = q.eq('sede_id', sede_id)
  if (etapa_id)   q = q.eq('etapa_id', etapa_id)
  if (version_libro) q = q.eq('version_libro', version_libro)
  if (estado)     q = q.eq('estado', estado)

  const { data, error, count } = await q
  if (error) return err(error.message, 500)

  let result = data??[]
  if (buscar) {
    const b = buscar.toLowerCase()
    result = result.filter((i:any)=>{
      const e = i.estudiante
      return e?.primer_nombre?.toLowerCase().includes(b)
        || e?.primer_apellido?.toLowerCase().includes(b)
        || e?.codigo_estudiante?.toLowerCase().includes(b)
        || e?.cui?.includes(b)
    })
  }
  return ok({ data: result, total: count??0, page, limit })
}

export async function POST(req: NextRequest) {
  const s = await getSession(req); if (!s) return err('No autorizado',401)
  if (!['tecnico','administrador'].includes(s.rol)) return err('Sin permiso',403)
  const b = await req.json()

  if (!b.primer_nombre||!b.primer_apellido||!b.telefono||!b.etapa_id||!b.sede_id)
    return err('Campos requeridos incompletos')
  if (!['viejo','nuevo'].includes(b.version_libro??'nuevo'))
    return err('version_libro debe ser viejo o nuevo')

  // Contar para código
  const { count } = await supabaseAdmin.from('estudiantes').select('*',{count:'exact',head:true})
  const codigo = `EST-${b.ciclo_escolar??2026}-${String((count??0)+1).padStart(4,'0')}`
  const correoU = b.correo ?? `${codigo.toLowerCase()}@pronea.gob.gt`

  // 1. Usuario
  const hash = await bcrypt.hash(`PRONEA${b.ciclo_escolar??2026}`,10)
  const { data: usu, error: eU } = await supabaseAdmin.from('usuarios')
    .insert({ correo:correoU, contrasena_hash:hash, rol:'estudiante', primer_ingreso:true })
    .select('id').single()
  if (eU) return err(eU.message, 500)

  // 2. Estudiante
  const { data: est, error: eE } = await supabaseAdmin.from('estudiantes').insert({
    usuario_id:usu.id, codigo_estudiante:codigo,
    primer_nombre:b.primer_nombre?.trim(), segundo_nombre:b.segundo_nombre?.trim()??null,
    primer_apellido:b.primer_apellido?.trim(), segundo_apellido:b.segundo_apellido?.trim()??null,
    apellido_casada:b.apellido_casada?.trim()??null,
    cui:b.cui_pendiente?null:b.cui?.replace(/\s/g,'')??null, cui_pendiente:b.cui_pendiente??false,
    fecha_nacimiento:b.fecha_nacimiento??null, genero:b.genero??null,
    telefono:b.telefono?.trim(), telefono_alternativo:b.telefono_alternativo?.trim()??null,
    correo:correoU, correo_classroom:b.correo_classroom?.trim()??null,
    direccion:b.direccion?.trim()??null, municipio_id:b.municipio_id??null,
    discapacidad_id:b.discapacidad_id??null, discapacidad_detalle:b.discapacidad_detalle?.trim()??null,
    conflicto_ley:b.conflicto_ley??false, becado_por:b.becado_por?.trim()??null,
  }).select('id').single()
  if (eE) return err(eE.message, 500)

  // 3. Inscripción
  const { data: insc, error: eI } = await supabaseAdmin.from('inscripciones').insert({
    estudiante_id:est.id, etapa_id:b.etapa_id, tecnico_id:b.tecnico_id??s.sub,
    sede_id:b.sede_id, institucion_id:b.institucion_id??null,
    modalidad_id:b.modalidad_id??null, seccion_id:b.seccion_id??null,
    ciclo_escolar:b.ciclo_escolar??2026, repite_etapa:b.repite_etapa??false,
    estado:'en_curso', estado_classroom:b.estado_classroom??null,
    codigo_sireex:b.codigo_sireex??null, observaciones:b.observaciones??null,
    version_libro:b.version_libro??'nuevo', creado_por:s.sub,
  }).select('id').single()
  if (eI) return err(eI.message, 500)

  // 4. Documentos
  if (b.documentos?.length>0) {
    const docs = b.documentos.filter((d:any)=>d.url_google_drive)
      .map((d:any)=>({ estudiante_id:est.id, tipo_documento_id:d.tipo_documento_id, url_google_drive:d.url_google_drive, estado:'en_revision' }))
    if (docs.length>0) await supabaseAdmin.from('documentos_estudiante').insert(docs)
  }

  await supabaseAdmin.from('auditoria').insert({ usuario_id:s.sub, accion:'INSERT', tabla_afectada:'estudiantes', registro_id:est.id, datos_nuevos:{ codigo, version_libro:b.version_libro, etapa_id:b.etapa_id } })

  return ok({ ok:true, estudiante_id:est.id, inscripcion_id:insc.id, codigo_estudiante:codigo, correo_usuario:correoU }, 201)
}
