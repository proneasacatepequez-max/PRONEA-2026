// src/app/api/notas/route.ts
// GET  tareas/exámenes filtrados por version_libro
// POST UPSERT nota tarea (0-5) o examen (0-100)
import { NextRequest } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'
import { getSession, ok, err } from '@/lib/auth'

export async function GET(req: NextRequest) {
  const s = await getSession(req); if (!s) return err('No autorizado',401)
  const p = req.nextUrl.searchParams
  const inscripcion_id=p.get('inscripcion_id'), num=p.get('numero_libro')??'1', tipo=p.get('tipo')??'tareas'
  if (!inscripcion_id) return err('inscripcion_id requerido')

  const { data: insc } = await supabaseAdmin.from('inscripciones')
    .select('id,etapa_id,version_libro,tiene_ajuste_discapacidad').eq('id',inscripcion_id).single()
  if (!insc) return err('Inscripción no encontrada',404)

  const { data: libro } = await supabaseAdmin.from('libros')
    .select('id,nombre,numero,version,total_tareas')
    .eq('etapa_id',insc.etapa_id).eq('numero',parseInt(num)).eq('version',insc.version_libro).eq('activo',true).single()
  if (!libro) return err(`No existe Libro ${num} versión "${insc.version_libro}" para esta etapa. Verifica la tabla libros.`,404)

  if (tipo==='tareas') {
    const { data: tareas } = await supabaseAdmin.from('tareas_catalogo')
      .select('id,numero_tarea,nombre,paginas,puntos_max,area:areas(id,nombre,codigo)')
      .eq('libro_id',libro.id).eq('activo',true).order('numero_tarea')

    const ids = (tareas??[]).map((t:any)=>t.id)
    const { data: notas } = await supabaseAdmin.from('notas_tareas')
      .select('id,tarea_id,nota,con_ajuste').eq('inscripcion_id',inscripcion_id).in('tarea_id',ids)
    const nm = Object.fromEntries((notas??[]).map((n:any)=>[n.tarea_id,n]))

    // Tareas omitidas por ajuste
    let omitidas: Set<string> = new Set()
    if (insc.tiene_ajuste_discapacidad) {
      const { data: adj } = await supabaseAdmin.from('ajustes_discapacidad')
        .select('tareas_omitidas_ajuste(tarea_id)')
        .eq('inscripcion_id',inscripcion_id).eq('activo',true)
      adj?.forEach((a:any)=>a.tareas_omitidas_ajuste?.forEach((t:any)=>omitidas.add(t.tarea_id)))
    }

    return ok({ libro, version_libro:insc.version_libro,
      tareas:(tareas??[]).map((t:any)=>({
        ...t, nota:nm[t.id]?.nota??null, con_ajuste:nm[t.id]?.con_ajuste??false,
        omitida:omitidas.has(t.id)
      }))
    })
  }

  const { data: examenes } = await supabaseAdmin.from('examenes_catalogo')
    .select('id,nombre,puntos_max,area:areas(id,nombre,codigo)')
    .eq('libro_id',libro.id).eq('activo',true)
  const eids = (examenes??[]).map((e:any)=>e.id)
  const { data: notas } = await supabaseAdmin.from('notas_examenes')
    .select('id,examen_id,nota_original,puntos_obtenidos').eq('inscripcion_id',inscripcion_id).in('examen_id',eids)
  const nm = Object.fromEntries((notas??[]).map((n:any)=>[n.examen_id,n]))
  return ok({ libro, version_libro:insc.version_libro,
    examenes:(examenes??[]).map((e:any)=>({ ...e, nota_original:nm[e.id]?.nota_original??null, puntos_obtenidos:nm[e.id]?.puntos_obtenidos??null }))
  })
}

export async function POST(req: NextRequest) {
  const s = await getSession(req); if (!s) return err('No autorizado',401)
  if (!['tecnico','administrador'].includes(s.rol)) return err('Sin permiso',403)
  const { tipo, inscripcion_id, tarea_id, examen_id, nota, nota_original } = await req.json()

  if (tipo==='tarea') {
    if (!tarea_id||nota===undefined||nota<0||nota>5) return err('tarea_id y nota(0-5) requeridos')
    const { error } = await supabaseAdmin.from('notas_tareas').upsert(
      { inscripcion_id, tarea_id, nota, registrado_por:s.sub, actualizado_en:new Date().toISOString() },
      { onConflict:'inscripcion_id,tarea_id' }
    )
    if (error) return err(error.message, 500)
    return ok({ ok:true, tipo:'tarea', nota })
  }
  if (tipo==='examen') {
    if (!examen_id||nota_original===undefined||nota_original<0||nota_original>100) return err('examen_id y nota_original(0-100) requeridos')
    const { error } = await supabaseAdmin.from('notas_examenes').upsert(
      { inscripcion_id, examen_id, nota_original, registrado_por:s.sub, actualizado_en:new Date().toISOString() },
      { onConflict:'inscripcion_id,examen_id' }
    )
    if (error) return err(error.message, 500)
    return ok({ ok:true, tipo:'examen', nota_original, puntos_obtenidos:Math.round(nota_original*20/100*100)/100 })
  }
  return err('tipo debe ser tarea o examen')
}
