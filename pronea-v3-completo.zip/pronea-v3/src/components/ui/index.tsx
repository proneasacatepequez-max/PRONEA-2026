'use client'
// src/components/ui/index.tsx
import { cn } from '@/lib/utils'
import { useState, useRef } from 'react'

// ── Badge ──────────────────────────────────────────────────
type BadgeVariant = 'green'|'red'|'yellow'|'blue'|'orange'|'gray'|'purple'
export function Badge({ children, variant='gray', className }:
  { children: React.ReactNode; variant?: BadgeVariant; className?: string }) {
  const v: Record<BadgeVariant,string> = {
    green:'badge-green', red:'badge-red', yellow:'badge-yellow',
    blue:'badge-blue', orange:'badge-orange', gray:'badge-gray', purple:'badge-purple'
  }
  return <span className={cn('badge', v[variant], className)}>{children}</span>
}

export function BadgeVersion({ v }: { v: 'nuevo'|'viejo' }) {
  return <span className={cn('badge', v==='nuevo'?'badge-blue':'badge-orange')}>
    {v==='nuevo'?'📗 Nuevo':'📙 Viejo'}
  </span>
}

export function BadgeEstado({ e }: { e: string }) {
  const m: Record<string,BadgeVariant> = {
    en_curso:'green', completada:'blue', retirada:'red',
    suspendida:'yellow', finalizada:'gray',
    abierto:'green', cerrado:'yellow', exportado:'blue',
    activo:'green', inactivo:'red',
  }
  const labels: Record<string,string> = {
    en_curso:'En curso', completada:'Completada', retirada:'Retirada',
    suspendida:'Suspendida', finalizada:'Finalizada',
    abierto:'Abierto', cerrado:'Cerrado', exportado:'Exportado',
    activo:'Activo', inactivo:'Inactivo',
  }
  return <Badge variant={m[e]??'gray'}>{labels[e]??e}</Badge>
}

// ── Stat Card ──────────────────────────────────────────────
export function StatCard({ icon, value, label, change, up, color='blue' }:
  { icon:string; value:string|number; label:string; change?:string; up?:boolean; color?:'blue'|'green'|'yellow'|'red' }) {
  return (
    <div className={`stat-card ${color}`}>
      <div className="text-3xl mb-1">{icon}</div>
      <div className="text-3xl font-extrabold text-gray-800 leading-none">{value}</div>
      <div className="text-sm text-gray-500 font-semibold mt-1">{label}</div>
      {change && <div className={cn('text-xs font-bold mt-1', up?'text-green-600':'text-red-600')}>{up?'↑':'↓'} {change}</div>}
    </div>
  )
}

// ── Modal ──────────────────────────────────────────────────
export function Modal({ open, onClose, title, children, footer, size='md' }:
  { open:boolean; onClose:()=>void; title:string; children:React.ReactNode; footer?:React.ReactNode; size?:'sm'|'md'|'lg'|'xl' }) {
  if (!open) return null
  const w = { sm:'max-w-sm', md:'max-w-lg', lg:'max-w-2xl', xl:'max-w-4xl' }
  return (
    <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div className={cn('modal-box', w[size])}>
        <div className="modal-header">
          <h3 className="text-base font-extrabold text-gray-800">{title}</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-2xl leading-none w-8 h-8 flex items-center justify-center">×</button>
        </div>
        <div className="modal-body">{children}</div>
        {footer&&<div className="modal-footer">{footer}</div>}
      </div>
    </div>
  )
}

// ── Form helpers ───────────────────────────────────────────
export function FormGroup({ label, required, children, hint, className }:
  { label:string; required?:boolean; children:React.ReactNode; hint?:string; className?:string }) {
  return (
    <div className={cn('fg', className)}>
      <label className="label">{label}{required&&<span className="text-red-500 ml-0.5">*</span>}</label>
      {children}
      {hint&&<p className="text-[11px] text-gray-400 mt-1">{hint}</p>}
    </div>
  )
}
export function Input(p: React.InputHTMLAttributes<HTMLInputElement>) {
  return <input {...p} className={cn('input', p.className)} />
}
export function Select(p: React.SelectHTMLAttributes<HTMLSelectElement>&{children:React.ReactNode}) {
  return <select {...p} className={cn('input', p.className)} />
}
export function Textarea(p: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea {...p} rows={p.rows??3} className={cn('input', p.className)} />
}

// ── Selector versión libro ─────────────────────────────────
export function SelectorVersionLibro({ value, onChange, disabled }:
  { value:'nuevo'|'viejo'; onChange:(v:'nuevo'|'viejo')=>void; disabled?:boolean }) {
  return (
    <div className="flex gap-2">
      {(['nuevo','viejo'] as const).map(v=>(
        <button key={v} type="button" disabled={disabled}
          onClick={()=>onChange(v)}
          className={cn('vsel-btn', value===v && v)}>
          <span className="text-2xl">{v==='nuevo'?'📗':'📙'}</span>
          <div>
            <div className={cn('text-sm font-bold', v==='nuevo'?'text-blue-700':'text-orange-700')}>
              Libro {v==='nuevo'?'Nuevo':'Viejo'}
            </div>
            <div className="text-xs text-gray-400">
              {v==='nuevo'?'Versión actualizada':'Estudiante en transición'}
            </div>
          </div>
        </button>
      ))}
    </div>
  )
}

// ── Barra de progreso ──────────────────────────────────────
export function BarraProgreso({ label, valor, max=100, color }:
  { label:string; valor:number; max?:number; color?:string }) {
  const pct = Math.min(100, Math.round(valor/max*100))
  const bg = color ?? (pct>=70?'#2EAD65':pct>=60?'#F4C430':'#D64545')
  return (
    <div className="flex items-center gap-3 mb-2">
      <div className="w-32 flex-shrink-0 text-sm font-semibold text-gray-600 truncate">{label}</div>
      <div className="progress-track">
        <div className="progress-fill" style={{width:`${pct}%`,backgroundColor:bg}}/>
      </div>
      <div className="w-10 text-right text-xs font-bold text-gray-600">{pct}%</div>
    </div>
  )
}

// ── Tabs ───────────────────────────────────────────────────
export function Tabs({ tabs, active, onChange }:
  { tabs:{id:string;label:string}[]; active:string; onChange:(id:string)=>void }) {
  return (
    <div className="tabs">
      {tabs.map(t=>(
        <div key={t.id} className={cn('tab', active===t.id&&'act')} onClick={()=>onChange(t.id)}>
          {t.label}
        </div>
      ))}
    </div>
  )
}

// ── Alert ──────────────────────────────────────────────────
export function Alert({ type='info', children }:
  { type?:'info'|'success'|'warning'|'error'; children:React.ReactNode }) {
  const t={info:'alert-i',success:'alert-s',warning:'alert-w',error:'alert-e'}
  return <div className={cn('alert', t[type])}>{children}</div>
}

// ── Spinner ────────────────────────────────────────────────
export function Spinner({ className }:{ className?:string }) {
  return (
    <div className={cn('flex items-center justify-center py-10', className)}>
      <div className="w-8 h-8 border-2 border-pronea border-t-transparent rounded-full animate-spin"/>
    </div>
  )
}

// ── Empty state ────────────────────────────────────────────
export function Empty({ icon='📭', msg }:{ icon?:string; msg:string }) {
  return (
    <div className="flex flex-col items-center justify-center py-14 text-gray-400">
      <div className="text-5xl mb-3">{icon}</div>
      <div className="text-sm font-semibold">{msg}</div>
    </div>
  )
}

// ── Confirm dialog ─────────────────────────────────────────
export function Confirm({ open, title, message, onConfirm, onCancel, danger=false }:
  { open:boolean; title:string; message:string; onConfirm:()=>void; onCancel:()=>void; danger?:boolean }) {
  return (
    <Modal open={open} onClose={onCancel} title={title} size="sm"
      footer={<>
        <button className="btn btn-ghost" onClick={onCancel}>Cancelar</button>
        <button className={cn('btn', danger?'btn-danger':'btn-primary')} onClick={onConfirm}>Confirmar</button>
      </>}>
      <p className="text-sm text-gray-600">{message}</p>
    </Modal>
  )
}

// ── Steps indicator ────────────────────────────────────────
export function Steps({ steps, current }:{ steps:string[]; current:number }) {
  return (
    <div className="flex items-center gap-2 mb-5">
      {steps.map((s,i)=>(
        <div key={i} className="flex items-center gap-2">
          <div className={cn('step-dot', i<current?'done':i===current?'cur':'todo')}>
            {i<current?'✓':i+1}
          </div>
          <span className={cn('text-sm font-bold hidden sm:block',
            i===current?'text-pronea':i<current?'text-green-600':'text-gray-400')}>{s}</span>
          {i<steps.length-1&&<div className="w-6 h-px bg-gray-200"/>}
        </div>
      ))}
    </div>
  )
}

// ── Loading button ─────────────────────────────────────────
export function LoadingBtn({ loading, children, className, ...props }:
  React.ButtonHTMLAttributes<HTMLButtonElement>&{loading?:boolean}) {
  return (
    <button {...props} disabled={loading||props.disabled}
      className={cn('btn', className, (loading||props.disabled)&&'opacity-50 cursor-not-allowed')}>
      {loading&&<span className="w-4 h-4 border-2 border-current/30 border-t-current rounded-full animate-spin"/>}
      {children}
    </button>
  )
}

// ── Nota input ─────────────────────────────────────────────
export function NotaInput({ value, max=5, onSave, disabled }:
  { value:number|null; max?:number; onSave:(n:number)=>void; disabled?:boolean }) {
  const [v, setV] = useState(value?.toString()??'')
  const num = parseFloat(v)
  const valid = !isNaN(num) && num>=0 && num<=max
  return (
    <input
      type="number" min={0} max={max} step={0.5}
      value={v} onChange={e=>setV(e.target.value)}
      disabled={disabled}
      onBlur={()=>{ if(valid && num!==value) onSave(num) }}
      onKeyDown={e=>{ if(e.key==='Enter' && valid && num!==value) onSave(num) }}
      className={cn(
        'w-16 px-2 py-1.5 border-2 rounded-lg text-sm font-bold text-center outline-none transition-all',
        value===null?'border-gray-200 bg-white':
        valid&&num>=(max*0.6)?'border-green-400 bg-green-50':'border-red-400 bg-red-50'
      )}
    />
  )
}
